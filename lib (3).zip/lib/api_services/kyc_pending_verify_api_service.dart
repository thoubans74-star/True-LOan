import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class KycPendingVerifyApiService {
  static const String baseUrl = 'https://trueloan.ai.in/ai/api/m_api/';

  /// Checks the pending KYC verification status using the type 1109 API
  static Future<Map<String, dynamic>?> checkKycStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String userId = prefs.getString('user_id') ?? '35';
      final String deviceId = prefs.getString('device_id') ?? '11';
      final String lt = prefs.getString('lt') ?? '22';
      final String ln = prefs.getString('ln') ?? '122';
      final String token = prefs.getString('token') ?? 'rt5yuu';

      final response = await http.post(
        Uri.parse(baseUrl),
        body: {
          'cid': '21472147',
          'ln': ln,
          'lt': lt,
          'device_id': deviceId,
          'type': '1109',
          'user_id': userId,
          'token': token,
        },
      );

      debugPrint('[KYC Status Check (1109)] Request user_id: $userId, token: $token');
      debugPrint('[KYC Status Check (1109)] Status: ${response.statusCode}, Body: ${response.body}');

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      }
    } catch (e) {
      debugPrint('Error in checkKycStatus: $e');
    }
    return null;
  }
}
