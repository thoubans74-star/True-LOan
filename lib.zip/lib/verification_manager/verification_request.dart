import 'package:flutter/material.dart';
import 'package:tm/verification_manager/app_colors.dart';
import 'schedule_field_visit.dart';

/// Model for a single verification request shown in the list.
class VerificationRequest {
  const VerificationRequest({
    required this.type,
    required this.name,
    required this.address,
    required this.assignedTime,
    required this.priority,
    this.isNewRequest = false,
  });

  final String type; // e.g. "BORROWER VERIFICATION", "LENDER AUDIT"
  final String name;
  final String address;
  final String assignedTime; // e.g. "10:30 AM" or "Yesterday"
  final RequestPriority priority;
  final bool isNewRequest;
}

enum RequestPriority { high, normal, standard }

extension on RequestPriority {
  String get label {
    switch (this) {
      case RequestPriority.high:
        return 'High';
      case RequestPriority.normal:
        return 'Normal';
      case RequestPriority.standard:
        return 'Standard';
    }
  }

  Color get color {
    switch (this) {
      case RequestPriority.high:
        return AppColors.red;
      case RequestPriority.normal:
        return AppColors.amberPriority;
      case RequestPriority.standard:
        return AppColors.textGrey;
    }
  }
}

/// "Requests" screen — green live-assignments banner + scrollable list of
/// request cards, each with a "Start Visit" CTA.
class VerificationRequestScreen extends StatelessWidget {
  const VerificationRequestScreen({
    super.key,
    this.requests = const [
      VerificationRequest(
        type: 'BORROWER VERIFICATION',
        name: 'Aravind Swamy',
        address: '42nd Floor, Brigade Tower, MG Road, Bangalore North, 560001',
        assignedTime: '10:30 AM',
        priority: RequestPriority.high,
        isNewRequest: true,
      ),
      VerificationRequest(
        type: 'LENDER AUDIT',
        name: 'Priya Sharma',
        address: 'Indiranagar 12th Main, Near Metro Station, Bangalore East, 560038',
        assignedTime: '09:15 AM',
        priority: RequestPriority.normal,
      ),
      VerificationRequest(
        type: 'BORROWER VERIFICATION',
        name: 'Karthik Narayanan',
        address: 'Sobha Dream Acres, Panathur Road, Varthur, Bangalore, 560087',
        assignedTime: 'Yesterday',
        priority: RequestPriority.standard,
      ),
    ],
    this.onBack,
    this.onStartVisit,
  });

  final List<VerificationRequest> requests;
  final VoidCallback? onBack;
  final void Function(VerificationRequest request)? onStartVisit;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.pageBg,
      body: SafeArea(
        child: Column(
          children: [
            _TopAppBar(title: 'Requests', onBack: onBack),
            _LiveAssignmentsBanner(count: requests.length),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                physics: const BouncingScrollPhysics(),
                itemCount: requests.length,
                separatorBuilder: (context, index) => const SizedBox(height: 14),
                itemBuilder: (context, i) {
                  final r = requests[i];
                  return _RequestCard(
                    request: r,
                    onStartVisit: () {
                      if (onStartVisit != null) {
                        onStartVisit!.call(r);
                      } else {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ScheduleFieldVisitScreen(),
                          ),
                        );
                      }
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TopAppBar extends StatelessWidget {
  const _TopAppBar({required this.title, this.onBack});

  final String title;
  final VoidCallback? onBack;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
      decoration: const BoxDecoration(gradient: AppColors.appBarGradient),
      child: Row(
        children: [
          IconButton(
            onPressed: onBack ?? () => Navigator.maybePop(context),
            icon: const Icon(Icons.arrow_back, color: Colors.white),
          ),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _LiveAssignmentsBanner extends StatelessWidget {
  const _LiveAssignmentsBanner({required this.count});

  final int count;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
      decoration: const BoxDecoration(gradient: AppColors.greenBannerGradient),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'ACTIVE ASSIGNMENTS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.6,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '$count Requests',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                const Text(
                  'Live Updates',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  const _RequestCard({required this.request, this.onStartVisit});

  final VerificationRequest request;
  final VoidCallback? onStartVisit;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.tagBg,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  request.type,
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textGrey,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
              if (request.isNewRequest)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.greenLightBg,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(
                        Icons.check_circle,
                        size: 12,
                        color: AppColors.greenText,
                      ),
                      SizedBox(width: 4),
                      Text(
                        'New Request',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          color: AppColors.greenText,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            request.name,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppColors.primaryBlue,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(
                Icons.location_on_outlined,
                size: 15,
                color: AppColors.textGrey,
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  request.address,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textGrey,
                    height: 1.3,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(height: 1, color: AppColors.cardBorder),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('ASSIGNED', style: AppText.label),
                    const SizedBox(height: 2),
                    Text(
                      request.assignedTime,
                      style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textDark,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('PRIORITY', style: AppText.label),
                    const SizedBox(height: 2),
                    Text(
                      request.priority.label,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: request.priority.color,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: onStartVisit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBlue,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 11),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Text(
                        'Start Visit',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(width: 4),
                      Icon(Icons.arrow_forward_rounded, size: 14),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
