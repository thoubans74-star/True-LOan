import 'package:flutter/material.dart';

/// A wrapper widget that dynamically scales its children to fit the device screen width
/// based on a target design width of 390 pixels.
///
/// It modifies the context's [MediaQueryData] so that child layouts calculate sizes
/// relative to the design dimensions, while a [Transform] visually scales the painted output.
class ResponsiveWrapper extends StatelessWidget {
  final Widget child;

  const ResponsiveWrapper({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final originalWidth = mediaQuery.size.width;
    final originalHeight = mediaQuery.size.height;

    // Use the standard design base width (390px, based on onboarding and splash layout assumptions)
    const designWidth = 390.0;
    
    // Fallback if the width is not set or invalid
    if (originalWidth <= 0) {
      return child;
    }

    final scale = originalWidth / designWidth;

    // If scale is exactly 1.0, bypass scaling
    if (scale == 1.0) {
      return child;
    }

    final scaledHeight = originalHeight / scale;

    return SizedBox(
      width: originalWidth,
      height: originalHeight,
      child: MediaQuery(
        data: mediaQuery.copyWith(
          size: Size(designWidth, scaledHeight),
          devicePixelRatio: mediaQuery.devicePixelRatio * scale,
          padding: mediaQuery.padding / scale,
          viewInsets: mediaQuery.viewInsets / scale,
          viewPadding: mediaQuery.viewPadding / scale,
        ),
        child: Transform(
          transform: Matrix4.diagonal3Values(scale, scale, 1.0),
          alignment: Alignment.topLeft,
          child: SizedBox(
            width: designWidth,
            height: scaledHeight,
            child: child,
          ),
        ),
      ),
    );
  }
}
