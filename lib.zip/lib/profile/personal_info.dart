import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../api_services/profile_api_service.dart';

class PersonalInfoScreen extends StatefulWidget {
  const PersonalInfoScreen({super.key});

  @override
  State<PersonalInfoScreen> createState() => _PersonalInfoScreenState();
}

class _PersonalInfoScreenState extends State<PersonalInfoScreen> {
  late final TextEditingController _nameController;
  late final TextEditingController _emailController;
  late final TextEditingController _phoneController;
  
  PlatformFile? _pickedFile;
  String? _emailError;
  bool _isSaving = false;
  String? _profileImageUrl;

  void _validateEmail(String value) {
    if (value.isEmpty) {
      setState(() {
        _emailError = null;
      });
      return;
    }
    if (!value.contains('.')) {
      setState(() {
        _emailError = "Email must contain at least one '.' (e.g., .com)";
      });
    } else {
      setState(() {
        _emailError = null;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _emailController = TextEditingController();
    _phoneController = TextEditingController();
    _loadProfileData();
  }

  Future<void> _loadProfileData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedName = prefs.getString('name') ?? 'Mohan';
      final cachedEmail = prefs.getString('email') ?? 'mohan@gmail.com';
      final cachedMobile = prefs.getString('mobile') ?? '98765 43219';
      final cachedImage = prefs.getString('profile_image');

      if (mounted) {
        setState(() {
          _nameController.text = cachedName;
          _emailController.text = cachedEmail;
          _phoneController.text = _formatMobile(cachedMobile);
          _profileImageUrl = cachedImage;
        });
      }

      final result = await ProfileApiService.fetchProfile();
      if (result != null && result['data'] != null && mounted) {
        final data = result['data'];
        setState(() {
          _nameController.text = data['name'] ?? _nameController.text;
          _emailController.text = data['email'] ?? _emailController.text;
          final rawMobile = data['mobile'] ?? data['phone'] ?? cachedMobile;
          _phoneController.text = _formatMobile(rawMobile);
          _profileImageUrl = data['profile_image'] ?? _profileImageUrl;
        });
      }
    } catch (e) {
      debugPrint("Error loading profile: $e");
    }
  }

  String _formatMobile(String mobile) {
    final text = mobile.replaceAll(RegExp(r'\D'), '');
    final digits = text.substring(0, text.length > 10 ? 10 : text.length);
    if (digits.length > 5) {
      return '${digits.substring(0, 5)} ${digits.substring(5)}';
    }
    return digits;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final FilePickerResult? result = await FilePicker.pickFiles(
        type: FileType.image,
      );
      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        final extension = file.extension?.toLowerCase();
        final allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
        
        if (extension != null && allowedExtensions.contains(extension)) {
          setState(() {
            _pickedFile = file;
          });
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'Only image formats (JPG, JPEG, PNG, GIF, BMP, WEBP) are allowed.',
                  style: GoogleFonts.poppins(fontSize: 13),
                ),
                backgroundColor: Colors.red.shade600,
              ),
            );
          }
        }
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // ── Blue AppBar (Same header design like Ads/MarketPlace) ──
          Container(
            color: const Color(0xFF004AC6),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(
                        Icons.arrow_back_rounded,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    Text(
                      'Edit Profile',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Scrollable Body with 20px padding matching other screens ──
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24), // Subtle top padding
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // ── Profile Photo Section ──
                  const SizedBox(height: 4),
                  GestureDetector(
                    onTap: _pickImage,
                    behavior: HitTestBehavior.opaque,
                    child: Stack(
                      alignment: Alignment.bottomRight,
                      children: [
                        Container(
                          width: 120,
                          height: 120,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white,
                              width: 4.0,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.08),
                                blurRadius: 16,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: _pickedFile != null
                                ? (kIsWeb
                                    ? (_pickedFile!.bytes != null
                                        ? Image.memory(
                                            _pickedFile!.bytes!,
                                            fit: BoxFit.cover,
                                          )
                                        : Image.asset(
                                            'assets/home/mohan_profile.png',
                                            fit: BoxFit.cover,
                                          ))
                                    : (_pickedFile!.path != null
                                        ? Image.file(
                                            File(_pickedFile!.path!),
                                            fit: BoxFit.cover,
                                          )
                                        : Image.asset(
                                            'assets/home/mohan_profile.png',
                                            fit: BoxFit.cover,
                                          )))
                                : (_profileImageUrl != null && _profileImageUrl!.startsWith('http')
                                    ? Image.network(
                                        _profileImageUrl!,
                                        fit: BoxFit.cover,
                                        errorBuilder: (context, error, stackTrace) => Image.asset(
                                          'assets/home/mohan_profile.png',
                                          fit: BoxFit.cover,
                                        ),
                                      )
                                    : Image.asset(
                                        'assets/home/mohan_profile.png',
                                        fit: BoxFit.cover,
                                      )),
                          ),
                        ),
                        // Camera Icon Badge
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: const BoxDecoration(
                            color: Color(0xFF004AC6),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.camera_alt_rounded,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10), // Subtle spacing

                  // ── KYC Verified Badge ──
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFC3FAE9), // Light green background from user edit
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.verified_rounded,
                          color: Color(0xFF009668), // Emerald checkmark
                          size: 20,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'KYC VERIFIED',
                          style: GoogleFonts.inter(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF009668),
                            letterSpacing: 0.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20), // Subtle spacing

                  // ── Input Fields Section ──
                  _buildInputField(
                    label: 'Full Name',
                    controller: _nameController,
                    icon: Icons.person_outline_rounded,
                    keyboardType: TextInputType.name,
                  ),
                  const SizedBox(height: 14),

                  _buildInputField(
                    label: 'Email Address',
                    controller: _emailController,
                    icon: Icons.mail_outline_rounded,
                    keyboardType: TextInputType.emailAddress,
                    errorText: _emailError,
                    onChanged: _validateEmail,
                  ),
                  const SizedBox(height: 14),

                  _buildInputField(
                    label: 'Phone Number',
                    controller: _phoneController,
                    icon: Icons.phone_android_rounded,
                    keyboardType: TextInputType.phone,
                    inputFormatters: [FiveDigitSpaceFormatter()],
                  ),
                  const SizedBox(height: 14),

                  // ── Verification Status Info Box ──
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF0F7FF), // Soft blue background
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFFE0E9F5), // Border outline
                        width: 1,
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Blue square shield container
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: const Color(0xFFDBEAFE), // Light blue box
                            borderRadius: BorderRadius.circular(8),
                          ),
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.verified_user_rounded,
                            color: Color(0xFF0284C7), // Blue check-shield
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Verification Status',
                                style: GoogleFonts.poppins(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xFF1E293B),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Your account is fully KYC verified. Most identity details are locked to ensure account security.',
                                style: GoogleFonts.poppins(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w400,
                                  color: const Color(0xFF64748B),
                                  height: 1.35,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  // ── Save Changes Button ──
                  ElevatedButton(
                    onPressed: _isSaving ? null : _saveChanges,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF004AC6),
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: const Color(0xFF82A3E8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      minimumSize: const Size(double.infinity, 48),
                      elevation: 0,
                    ),
                    child: _isSaving
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : Text(
                            'Save Changes',
                            style: GoogleFonts.poppins(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _saveChanges() async {
    if (_nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter your name.', style: GoogleFonts.poppins(fontSize: 13)),
          backgroundColor: Colors.red.shade600,
        ),
      );
      return;
    }
    
    if (_emailController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter your email.', style: GoogleFonts.poppins(fontSize: 13)),
          backgroundColor: Colors.red.shade600,
        ),
      );
      return;
    }

    if (_emailError != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please fix email validation errors.', style: GoogleFonts.poppins(fontSize: 13)),
          backgroundColor: Colors.red.shade600,
        ),
      );
      return;
    }

    final cleanMobile = _phoneController.text.replaceAll(' ', '');
    if (cleanMobile.length != 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Phone number must be exactly 10 digits.', style: GoogleFonts.poppins(fontSize: 13)),
          backgroundColor: Colors.red.shade600,
        ),
      );
      return;
    }

    setState(() {
      _isSaving = true;
    });

    final response = await ProfileApiService.updateProfile(
      name: _nameController.text.trim(),
      email: _emailController.text.trim(),
      mobile: cleanMobile,
      pickedFile: _pickedFile,
    );

    setState(() {
      _isSaving = false;
    });

    if (response != null && response['status'] == 'success') {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(response['message'] ?? 'Profile updated successfully', style: GoogleFonts.poppins(fontSize: 13)),
            backgroundColor: Colors.green.shade600,
          ),
        );
        Navigator.of(context).pop(true);
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(response?['message'] ?? 'Failed to update profile. Please try again.', style: GoogleFonts.poppins(fontSize: 13)),
            backgroundColor: Colors.red.shade600,
          ),
        );
      }
    }
  }

  Widget _buildInputField({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    List<TextInputFormatter>? inputFormatters,
    String? errorText,
    ValueChanged<String>? onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF42474E),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          width: double.infinity,
          height: 52,
          decoration: BoxDecoration(
            color: const Color(0xFFF1F3F9), // Light grey background
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            inputFormatters: inputFormatters,
            onChanged: onChanged,
            style: GoogleFonts.poppins(
              fontSize: 15,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF191C20),
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: const EdgeInsets.only(left: 16, top: 14, bottom: 14),
              suffixIcon: Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Icon(
                  icon,
                  color: const Color(0x6642474E), // Suffix icon (40% opacity)
                  size: 25,
                ),
              ),
              suffixIconConstraints: const BoxConstraints(
                minHeight: 25,
                minWidth: 25,
              ),
            ),
          ),
        ),
        if (errorText != null) ...[
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.only(left: 4),
            child: Text(
              errorText,
              style: GoogleFonts.poppins(
                fontSize: 11,
                color: Colors.red.shade600,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ],
    );
  }
}

class FiveDigitSpaceFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final text = newValue.text.replaceAll(RegExp(r'\D'), '');
    final digits = text.substring(0, text.length > 10 ? 10 : text.length);
    
    String formatted = '';
    if (digits.length > 5) {
      formatted = '${digits.substring(0, 5)} ${digits.substring(5)}';
    } else {
      formatted = digits;
    }
    
    int digitCountBeforeSelection = 0;
    
    for (int i = 0; i < newValue.selection.end && i < newValue.text.length; i++) {
      if (RegExp(r'\d').hasMatch(newValue.text[i])) {
        digitCountBeforeSelection++;
      }
    }
    
    if (digitCountBeforeSelection > 10) {
      digitCountBeforeSelection = 10;
    }
    
    int newSelectionEnd = digitCountBeforeSelection;
    if (digitCountBeforeSelection > 5) {
      newSelectionEnd += 1;
    }
    
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: newSelectionEnd),
    );
  }
}
