import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:file_picker/file_picker.dart';

/// Shows the main sector selection bottom sheet.
void showSectorSelectionBottomSheet(
  BuildContext context, {
  required VoidCallback onSuccess,
}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      return SectorSelectionBottomSheet(onSuccess: onSuccess);
    },
  );
}

class SectorSelectionBottomSheet extends StatelessWidget {
  final VoidCallback onSuccess;

  const SectorSelectionBottomSheet({super.key, required this.onSuccess});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Container(
            width: 48,
            height: 5,
            decoration: BoxDecoration(
              color: const Color(0xFFE2E8F0),
              borderRadius: BorderRadius.circular(2.5),
            ),
          ),
          const SizedBox(height: 24),
          _buildSectorButton(
            context: context,
            label: 'Private Sector',
            onTap: () {
              Navigator.pop(context); // Close selection sheet
              _showPrivateSectorSheet(context, onSuccess);
            },
          ),
          const SizedBox(height: 14),
          _buildSectorButton(
            context: context,
            label: 'NBFC',
            onTap: () {
              Navigator.pop(context); // Close selection sheet
              _showNbfcSheet(context, onSuccess);
            },
          ),
          const SizedBox(height: 14),
          _buildSectorButton(
            context: context,
            label: 'Bank Sector',
            onTap: () {
              Navigator.pop(context); // Close selection sheet
              _showBankSheet(context, onSuccess);
            },
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildSectorButton({
    required BuildContext context,
    required String label,
    required VoidCallback onTap,
  }) {
    return Container(
      width: double.infinity,
      height: 58,
      decoration: BoxDecoration(
        color: const Color(0xFF0056D2), // premium blue matching screenshot
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Center(
            child: Text(
              label,
              style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── Private Sector Bottom Sheet ──────────────────────────────────────────────
void _showPrivateSectorSheet(BuildContext context, VoidCallback onSuccess) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      return PrivateSectorVerificationBottomSheet(onSuccess: onSuccess);
    },
  );
}

class PrivateSectorVerificationBottomSheet extends StatefulWidget {
  final VoidCallback onSuccess;

  const PrivateSectorVerificationBottomSheet({
    super.key,
    required this.onSuccess,
  });

  @override
  State<PrivateSectorVerificationBottomSheet> createState() =>
      _PrivateSectorVerificationBottomSheetState();
}

class _PrivateSectorVerificationBottomSheetState
    extends State<PrivateSectorVerificationBottomSheet> {
  String? _bankStatementFileName;
  String? _itrFileName;
  String? _salarySlipsFileName;
  String? _panFileName;

  Future<void> _pickFile(int index) async {
    try {
      final result = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png', 'pdf'],
      );

      if (result != null && result.files.isNotEmpty) {
        setState(() {
          final fileName = result.files.single.name;
          if (index == 0) {
            _bankStatementFileName = fileName;
          } else if (index == 1) {
            _itrFileName = fileName;
          } else if (index == 2) {
            _salarySlipsFileName = fileName;
          } else if (index == 3) {
            _panFileName = fileName;
          }
        });
      }
    } catch (e) {
      debugPrint('Error picking file: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final sheetHeight = mediaQuery.size.height * 0.85;

    return Container(
      height: sheetHeight,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 48,
            height: 5,
            decoration: BoxDecoration(
              color: const Color(0xFFE2E8F0),
              borderRadius: BorderRadius.circular(2.5),
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(
                    Icons.close,
                    color: Color(0xFF0058BE),
                    size: 24,
                  ),
                  onPressed: () => Navigator.pop(context),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Private Sector Verification',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF191C1E),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: Color(0xFFE2E8F0)),
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSectionTitle('IDENTITY PROOF'),
                  const SizedBox(height: 12),
                  _buildIdentityCard(
                    icon: 'assets/profile/aadhar card.png',
                    iconBgColor: const Color(0xFFEFF6FF),
                    iconColor: const Color(0xFF2563EB),
                    title: 'Aadhaar Card',
                    statusText: 'Verified',
                    statusColor: const Color(0xFF004AC6),
                    isVerified: true,
                    rightWidget: const Icon(
                      Icons.chevron_right_rounded,
                      color: Color(0xFF94A3B8),
                      size: 24,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildIdentityCard(
                    icon: Icons.credit_card_rounded,
                    iconBgColor: const Color(0xFFF1F5F9),
                    iconColor: const Color(0xFF64748B),
                    title: 'PAN Card',
                    statusText: _panFileName != null
                        ? 'Uploaded'
                        : 'Action Required',
                    statusColor: _panFileName != null
                        ? const Color(0xFF004AC6)
                        : const Color(0xFFBA1A1A),
                    isVerified: _panFileName != null,
                    rightWidget: _panFileName != null
                        ? Text(
                            _panFileName!,
                            style: GoogleFonts.poppins(
                              fontSize: 10,
                              color: const Color(0xFF004AC6),
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          )
                        : ElevatedButton(
                            onPressed: () => _pickFile(3),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF004AC6),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 6,
                              ),
                              minimumSize: Size.zero,
                              elevation: 0,
                            ),
                            child: Text(
                              'Upload',
                              style: GoogleFonts.poppins(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                  ),
                  const SizedBox(height: 24),

                  _buildSectionTitle('BANK ACCOUNT VERIFICATION'),
                  const SizedBox(height: 12),
                  CustomPaint(
                    painter: DashedRectPainter(
                      color: const Color(0xFFCBD5E1),
                      gap: 4.0,
                    ),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: 56,
                            height: 56,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x0F000000),
                                  blurRadius: 8,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                            alignment: Alignment.center,
                            child: const Icon(
                              Icons.account_balance_rounded,
                              size: 28,
                              color: Color(0xFF0058BE),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Primary bank account linked successfully.',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.poppins(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xFF191C1E),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  _buildSectionTitle('FINANCIAL CAPACITY PROOF'),
                  const SizedBox(height: 4),
                  Text(
                    'Upload any one of the following.',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: const Color(0xFF64748B),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildFinancialCard(
                    icon: Icons.description_outlined,
                    title: 'Last 6 Months Bank Statement',
                    fileName: _bankStatementFileName,
                    onUpload: () => _pickFile(0),
                    onRemove: () =>
                        setState(() => _bankStatementFileName = null),
                  ),
                  const SizedBox(height: 12),
                  _buildFinancialCard(
                    icon: Icons.receipt_long_outlined,
                    title: 'Latest ITR Acknowledgement',
                    fileName: _itrFileName,
                    onUpload: () => _pickFile(1),
                    onRemove: () => setState(() => _itrFileName = null),
                  ),
                  const SizedBox(height: 12),
                  _buildFinancialCard(
                    icon: Icons.payments_outlined,
                    title: 'Salary Slips (last 3 months)',
                    fileName: _salarySlipsFileName,
                    onUpload: () => _pickFile(2),
                    onRemove: () => setState(() => _salarySlipsFileName = null),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                widget.onSuccess();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0056D2),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                minimumSize: const Size(double.infinity, 48),
                elevation: 0,
              ),
              child: Text(
                'Complete Verification',
                style: GoogleFonts.poppins(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: GoogleFonts.poppins(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        color: const Color(0xFF45464D),
        letterSpacing: 0.6,
      ),
    );
  }

  Widget _buildIdentityCard({
    required dynamic icon,
    required Color iconBgColor,
    required Color iconColor,
    required String title,
    required String statusText,
    required Color statusColor,
    required bool isVerified,
    required Widget rightWidget,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0), width: 1.5),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: iconBgColor,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: icon is IconData
                ? Icon(icon, color: iconColor, size: 24)
                : (icon is String
                      ? Image.asset(
                          icon,
                          width: 24,
                          height: 24,
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) => Icon(
                            Icons.credit_card,
                            color: iconColor,
                            size: 24,
                          ),
                        )
                      : const SizedBox.shrink()),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF1E293B),
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    if (isVerified) ...[
                      const Icon(
                        Icons.check_circle_rounded,
                        color: Color(0xFF004AC6),
                        size: 14,
                      ),
                      const SizedBox(width: 4),
                    ],
                    Text(
                      statusText,
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: statusColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          rightWidget,
        ],
      ),
    );
  }

  Widget _buildFinancialCard({
    required IconData icon,
    required String title,
    required String? fileName,
    required VoidCallback onUpload,
    required VoidCallback onRemove,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0), width: 1.5),
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF64748B), size: 22),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF1E293B),
                  ),
                ),
                if (fileName != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    fileName,
                    style: GoogleFonts.poppins(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF004AC6),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
          if (fileName == null)
            InkWell(
              onTap: onUpload,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                width: 32,
                height: 32,
                decoration: const BoxDecoration(
                  color: Color(0xFFEFF6FF),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.file_upload_outlined,
                  color: Color(0xFF2563EB),
                  size: 18,
                ),
              ),
            )
          else
            IconButton(
              icon: const Icon(
                Icons.delete_outline_rounded,
                color: Color(0xFFEF4444),
                size: 20,
              ),
              onPressed: onRemove,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
        ],
      ),
    );
  }
}

// ── NBFC Verification Bottom Sheet ───────────────────────────────────────────
void _showNbfcSheet(BuildContext context, VoidCallback onSuccess) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      return NbfcVerificationBottomSheet(onSuccess: onSuccess);
    },
  );
}

class NbfcVerificationBottomSheet extends StatefulWidget {
  final VoidCallback onSuccess;

  const NbfcVerificationBottomSheet({super.key, required this.onSuccess});

  @override
  State<NbfcVerificationBottomSheet> createState() =>
      _NbfcVerificationBottomSheetState();
}

class _NbfcVerificationBottomSheetState
    extends State<NbfcVerificationBottomSheet> {
  final _cinController = TextEditingController();
  final _panController = TextEditingController();
  final _rbiRegController = TextEditingController();
  String? _corFileName;

  Future<void> _pickCorFile() async {
    try {
      final result = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png', 'pdf'],
      );
      if (result != null && result.files.isNotEmpty) {
        setState(() {
          _corFileName = result.files.single.name;
        });
      }
    } catch (e) {
      debugPrint('Error picking COR file: $e');
    }
  }

  @override
  void dispose() {
    _cinController.dispose();
    _panController.dispose();
    _rbiRegController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final sheetHeight = mediaQuery.size.height * 0.85;

    return Container(
      height: sheetHeight,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 48,
            height: 5,
            decoration: BoxDecoration(
              color: const Color(0xFFE2E8F0),
              borderRadius: BorderRadius.circular(2.5),
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(
                    Icons.close,
                    color: Color(0xFF0056D2),
                    size: 24,
                  ),
                  onPressed: () => Navigator.pop(context),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'NBFC Verification',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF191C1E),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFC3FAE9), // Light green capsule
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'Progress: 25%',
                    style: GoogleFonts.poppins(
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF004AC6),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: Color(0xFFE2E8F0)),
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Column(
                children: [
                  // CARD 1: Company Registration
                  _buildFormCard(
                    icon: Icons.business_rounded,
                    title: 'Company Registration',
                    children: [
                      _buildFieldLabel('Corporate Identification Number (CIN)'),
                      const SizedBox(height: 8),
                      _buildTextField(
                        controller: _cinController,
                        hintText: 'U12345DL2023PTC123456',
                      ),
                      const SizedBox(height: 16),
                      _buildFieldLabel('Company PAN Card Number'),
                      const SizedBox(height: 8),
                      _buildTextField(
                        controller: _panController,
                        hintText: 'ABCDE1234F',
                        textCapitalization: TextCapitalization.characters,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // CARD 2: RBI Authorization
                  _buildFormCard(
                    icon: Icons.gavel_rounded,
                    title: 'RBI Authorization',
                    children: [
                      _buildFieldLabel('RBI Registration Number'),
                      const SizedBox(height: 8),
                      _buildTextField(
                        controller: _rbiRegController,
                        hintText: 'B.14.XXXXX',
                        textCapitalization: TextCapitalization.characters,
                      ),
                      const SizedBox(height: 16),
                      _buildFieldLabel('RBI Certificate of Registration'),
                      const SizedBox(height: 8),
                      _buildCorUploadBox(
                        fileName: _corFileName,
                        onTap: _pickCorFile,
                        onRemove: () => setState(() => _corFileName = null),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                widget.onSuccess();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(
                  0xFF0056D2,
                ), // matching blue button
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                minimumSize: const Size(double.infinity, 48),
                elevation: 0,
              ),
              child: Text(
                'Submit for Verification',
                style: GoogleFonts.poppins(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormCard({
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFEEF2F6), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: const Color(0xFF0056D2), size: 22),
              const SizedBox(width: 8),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xFF1E293B),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  Widget _buildFieldLabel(String label) {
    return Text(
      label,
      style: GoogleFonts.poppins(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: const Color(0xFF1E293B),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    TextCapitalization textCapitalization = TextCapitalization.none,
  }) {
    return Container(
      height: 44,
      decoration: BoxDecoration(
        color: const Color(0xFFF1F3F9), // Light grey matching screenshot
        borderRadius: BorderRadius.circular(10),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      alignment: Alignment.centerLeft,
      child: TextField(
        controller: controller,
        textCapitalization: textCapitalization,
        style: GoogleFonts.poppins(
          fontSize: 13,
          fontWeight: FontWeight.w500,
          color: const Color(0xFF1E293B),
        ),
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: hintText,
          hintStyle: GoogleFonts.poppins(
            fontSize: 13,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF94A3B8),
          ),
          contentPadding: EdgeInsets.zero,
          isDense: true,
        ),
      ),
    );
  }

  Widget _buildCorUploadBox({
    required String? fileName,
    required VoidCallback onTap,
    required VoidCallback onRemove,
  }) {
    return CustomPaint(
      painter: DashedRectPainter(color: const Color(0xFFCBD5E1), gap: 4.0),
      child: InkWell(
        onTap: fileName == null ? onTap : null,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: const Color(0xFFF8FAFC),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            children: [
              const Icon(
                Icons.verified_user_outlined,
                color: Color(0xFF64748B),
                size: 20,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      fileName ?? 'RBI Certificate of Registration',
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF1E293B),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      fileName != null
                          ? 'File Uploaded'
                          : 'Upload Original COR',
                      style: GoogleFonts.poppins(
                        fontSize: 10,
                        color: const Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
              if (fileName == null)
                const Icon(
                  Icons.add_circle_outline_rounded,
                  color: Color(0xFF0056D2),
                  size: 24,
                )
              else
                IconButton(
                  icon: const Icon(
                    Icons.delete_outline_rounded,
                    color: Color(0xFFEF4444),
                    size: 20,
                  ),
                  onPressed: onRemove,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Bank Sector Verification Bottom Sheet ────────────────────────────────────
void _showBankSheet(BuildContext context, VoidCallback onSuccess) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      return BankVerificationBottomSheet(onSuccess: onSuccess);
    },
  );
}

class BankVerificationBottomSheet extends StatefulWidget {
  final VoidCallback onSuccess;

  const BankVerificationBottomSheet({super.key, required this.onSuccess});

  @override
  State<BankVerificationBottomSheet> createState() =>
      _BankVerificationBottomSheetState();
}

class _BankVerificationBottomSheetState
    extends State<BankVerificationBottomSheet> {
  final _licenseController = TextEditingController();
  final _panController = TextEditingController();
  final _rbiApproveController = TextEditingController();
  String? _corFileName;

  Future<void> _pickCorFile() async {
    try {
      final result = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png', 'pdf'],
      );
      if (result != null && result.files.isNotEmpty) {
        setState(() {
          _corFileName = result.files.single.name;
        });
      }
    } catch (e) {
      debugPrint('Error picking COR file: $e');
    }
  }

  @override
  void dispose() {
    _licenseController.dispose();
    _panController.dispose();
    _rbiApproveController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final sheetHeight = mediaQuery.size.height * 0.85;

    return Container(
      height: sheetHeight,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 48,
            height: 5,
            decoration: BoxDecoration(
              color: const Color(0xFFE2E8F0),
              borderRadius: BorderRadius.circular(2.5),
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(
                    Icons.close,
                    color: Color(0xFF0056D2),
                    size: 24,
                  ),
                  onPressed: () => Navigator.pop(context),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Bank Sector Verification',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF191C1E),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(
                      255,
                      187,
                      241,
                      219,
                    ), // Light green capsule
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'Progress: 25%',
                    style: GoogleFonts.poppins(
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF009668),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: Color(0xFFE2E8F0)),
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Column(
                children: [
                  // CARD 1: Bank Registration
                  _buildFormCard(
                    icon: Icons.account_balance_rounded,
                    title: 'Bank Registration',
                    children: [
                      _buildFieldLabel('Bank License Number'),
                      const SizedBox(height: 8),
                      _buildTextField(
                        controller: _licenseController,
                        hintText: 'L-12345-XXXX',
                      ),
                      const SizedBox(height: 16),
                      _buildFieldLabel('Bank PAN Card Number'),
                      const SizedBox(height: 8),
                      _buildTextField(
                        controller: _panController,
                        hintText: 'BANK1234F',
                        textCapitalization: TextCapitalization.characters,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // CARD 2: RBI Authorization
                  _buildFormCard(
                    icon: Icons.gavel_rounded,
                    title: 'RBI Authorization',
                    children: [
                      _buildFieldLabel('RBI Approval Code'),
                      const SizedBox(height: 8),
                      _buildTextField(
                        controller: _rbiApproveController,
                        hintText: 'RBI-APP-XXXX',
                        textCapitalization: TextCapitalization.characters,
                      ),
                      const SizedBox(height: 16),
                      _buildFieldLabel('RBI Certificate of Registration'),
                      const SizedBox(height: 8),
                      _buildCorUploadBox(
                        fileName: _corFileName,
                        onTap: _pickCorFile,
                        onRemove: () => setState(() => _corFileName = null),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                widget.onSuccess();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(
                  0xFF0056D2,
                ), // matching blue button
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                minimumSize: const Size(double.infinity, 48),
                elevation: 0,
              ),
              child: Text(
                'Submit for Verification',
                style: GoogleFonts.poppins(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormCard({
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFEEF2F6), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: const Color(0xFF0056D2), size: 22),
              const SizedBox(width: 8),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xFF1E293B),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  Widget _buildFieldLabel(String label) {
    return Text(
      label,
      style: GoogleFonts.poppins(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: const Color(0xFF1E293B),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    TextCapitalization textCapitalization = TextCapitalization.none,
  }) {
    return Container(
      height: 44,
      decoration: BoxDecoration(
        color: const Color(0xFFF1F3F9), // Light grey matching screenshot
        borderRadius: BorderRadius.circular(10),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      alignment: Alignment.centerLeft,
      child: TextField(
        controller: controller,
        textCapitalization: textCapitalization,
        style: GoogleFonts.poppins(
          fontSize: 13,
          fontWeight: FontWeight.w500,
          color: const Color(0xFF1E293B),
        ),
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: hintText,
          hintStyle: GoogleFonts.poppins(
            fontSize: 13,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF94A3B8),
          ),
          contentPadding: EdgeInsets.zero,
          isDense: true,
        ),
      ),
    );
  }

  Widget _buildCorUploadBox({
    required String? fileName,
    required VoidCallback onTap,
    required VoidCallback onRemove,
  }) {
    return CustomPaint(
      painter: DashedRectPainter(color: const Color(0xFFCBD5E1), gap: 4.0),
      child: InkWell(
        onTap: fileName == null ? onTap : null,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: const Color(0xFFF8FAFC),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            children: [
              const Icon(
                Icons.verified_user_outlined,
                color: Color(0xFF64748B),
                size: 20,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      fileName ?? 'RBI Certificate of Registration',
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF1E293B),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      fileName != null
                          ? 'File Uploaded'
                          : 'Upload Original COR',
                      style: GoogleFonts.poppins(
                        fontSize: 10,
                        color: const Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
              if (fileName == null)
                const Icon(
                  Icons.add_circle_outline_rounded,
                  color: Color(0xFF0056D2),
                  size: 24,
                )
              else
                IconButton(
                  icon: const Icon(
                    Icons.delete_outline_rounded,
                    color: Color(0xFFEF4444),
                    size: 20,
                  ),
                  onPressed: onRemove,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── DashedRectPainter ────────────────────────────────────────────────────────
class DashedRectPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  final double gap;

  DashedRectPainter({
    this.color = const Color(0xFF94A3B8),
    this.strokeWidth = 1.0,
    this.gap = 4.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;

    final Path path = Path();
    path.addRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.width, size.height),
        const Radius.circular(8),
      ),
    );

    final Path dashedPath = Path();
    double distance = 0.0;
    for (final PathMetric measure in path.computeMetrics()) {
      while (distance < measure.length) {
        dashedPath.addPath(
          measure.extractPath(distance, distance + gap),
          Offset.zero,
        );
        distance += gap * 2;
      }
    }
    canvas.drawPath(dashedPath, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
