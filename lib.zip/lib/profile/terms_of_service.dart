import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TermsOfServiceScreen extends StatelessWidget {
  const TermsOfServiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF004AC6),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.maybePop(context),
        ),
        title: Text(
          'Terms and Conditions',
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: false,
        titleSpacing: 0,
      ),
      body: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Effective Date Badge
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/home/shield.png',
                  width: 20,
                  height: 20,
                  fit: BoxFit.contain,
                ),
                const SizedBox(width: 6),
                Text(
                  'EFFECTIVE: OCTOBER 2023',
                  style: GoogleFonts.poppins(
                    color: const Color(0xFF009668),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.6,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Legal Agreement
            Text(
              'Legal Agreement',
              style: GoogleFonts.poppins(
                color: const Color(0xFF191C1E),
                fontSize: 22,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),

            // Intro Text
            Text(
              'Please read these terms carefully before using the TrueMoney platform. By accessing our services, you agree to be bound by these requirements.',
              style: GoogleFonts.poppins(
                color: const Color(0xFF45464D),
                fontSize: 13,
                fontWeight: FontWeight.w400,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),

            // 1. Introduction
            _buildSectionHeader('1.', 'Introduction'),
            const SizedBox(height: 12),
            Text(
              'Welcome to TrueMoney. These Terms and Conditions constitute a legally binding agreement made between you, whether personally or on behalf of an entity ("you") and TrueMoney ("we," "us" or "our"), concerning your access to and use of our mobile application and financial services. You agree that by accessing the application, you have read, understood, and agreed to be bound by all of these Terms and Conditions.',
              style: GoogleFonts.poppins(
                color: const Color(0xFF45464D),
                fontSize: 13,
                fontWeight: FontWeight.w400,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'IF YOU DO NOT AGREE WITH ALL OF THESE TERMS AND CONDITIONS, THEN YOU ARE EXPRESSLY PROHIBITED FROM USING THE APP AND YOU MUST DISCONTINUE USE IMMEDIATELY.',
              style: GoogleFonts.poppins(
                color: const Color(0xFF45464D),
                fontSize: 13,
                fontWeight: FontWeight.w500,
                height: 1.6,
              ),
            ),
            const SizedBox(height: 24),

            // 2. Eligibility
            _buildSectionHeader('2.', 'Eligibility'),
            const SizedBox(height: 12),
            Text(
              'The services offered by TrueMoney are intended solely for users who are eighteen (18) years of age or older. Any registration by, use of or access to the app by anyone under 18 is unauthorized, unlicensed and in violation of these Terms. By using the services, you represent and warrant that you are 18 or older and that you agree to abide by all of the terms and conditions of this Agreement.',
              style: GoogleFonts.poppins(
                color: const Color(0xFF45464D),
                fontSize: 13,
                fontWeight: FontWeight.w400,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),

            // 3. User Obligations
            _buildSectionHeader('3.', 'User Obligations'),
            const SizedBox(height: 12),
            _buildBulletItem(
              'You must provide accurate, current, and complete information during the registration process.',
            ),
            const SizedBox(height: 12),
            _buildBulletItem(
              'You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.',
            ),
            const SizedBox(height: 12),
            _buildBulletItem(
              'You agree to notify us immediately of any unauthorized use of your account or any other breach of security.',
            ),
            const SizedBox(height: 12),
            _buildBulletItem(
              'The service must not be used for any illegal or unauthorized purpose, including but not limited to money laundering or fraudulent transactions.',
            ),
            const SizedBox(height: 24),

            // Investment Notice Container
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              decoration: BoxDecoration(
                color: const Color(0x0D2170E4), // #2170E40D
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(12),
                  bottomRight: Radius.circular(12),
                ),
                border: const Border(
                  left: BorderSide(color: Color(0xFF2170E4), width: 4),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.info_outline_rounded,
                        color: Color(0xFF2170E4),
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Investment Notice',
                        style: GoogleFonts.poppins(
                          color: const Color(0xFF004395),
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 28),
                    child: Text(
                      'All financial instruments involve risk. Past performance is not a guarantee of future results.',
                      style: GoogleFonts.poppins(
                        color: const Color(0xFF45464D),
                        fontSize: 12.5,
                        fontWeight: FontWeight.w400,
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 4. Investment Risks
            _buildSectionHeader('4.', 'Investment Risks'),
            const SizedBox(height: 12),
            Text(
              'The value of investments and the income from them can fall as well as rise and you may not get back the amount originally invested. Decisions to buy, sell or hold any financial instrument involve risk and are best made based on the advice of qualified financial professionals. Any "backtesting" or "simulated" performance results have certain inherent limitations.',
              style: GoogleFonts.poppins(
                color: const Color(0xFF45464D),
                fontSize: 13,
                fontWeight: FontWeight.w400,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'TrueMoney provides tools for data analysis but does not provide personalized investment advice. You are solely responsible for determining whether any investment is appropriate for you based on your personal objectives and financial situation.',
              style: GoogleFonts.poppins(
                color: const Color(0xFF45464D),
                fontSize: 13,
                fontWeight: FontWeight.w400,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),

            // 5. Privacy Policy
            _buildSectionHeader('5.', 'Privacy Policy'),
            const SizedBox(height: 12),
            Text.rich(
              TextSpan(
                style: GoogleFonts.poppins(
                  color: const Color(0xFF45464D),
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                  height: 1.5,
                ),
                children: [
                  const TextSpan(
                    text: 'Your privacy is important to us. Please review our ',
                  ),
                  TextSpan(
                    text: 'Privacy Policy',
                    style: const TextStyle(
                      color: Color(0xFF0058BE),
                      fontWeight: FontWeight.w600,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const TextSpan(
                    text:
                        ', which also governs your use of our services, to understand our practices. We use industry-standard encryption and security protocols to ensure your data remains protected at all times.',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String number, String title) {
    return RichText(
      text: TextSpan(
        style: GoogleFonts.poppins(fontSize: 22, fontWeight: FontWeight.w600),
        children: [
          TextSpan(
            text: number,
            style: const TextStyle(color: Color(0xFF009668)),
          ),
          const TextSpan(text: ' '),
          TextSpan(
            text: title,
            style: const TextStyle(color: Color(0xFF191C1E)),
          ),
        ],
      ),
    );
  }

  Widget _buildBulletItem(String text) {
    return Text(
      text,
      style: GoogleFonts.poppins(
        color: const Color(0xFF45464D),
        fontSize: 13,
        fontWeight: FontWeight.w400,
        height: 1.5,
      ),
    );
  }
}
