import 'dart:ui';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tm/profile/verification_sheets.dart';

class KycVerificationScreen extends StatefulWidget {
  const KycVerificationScreen({super.key});

  @override
  State<KycVerificationScreen> createState() => _KycVerificationScreenState();
}

class _KycVerificationScreenState extends State<KycVerificationScreen> {
  int? _expandedIndex; // 0: PAN, 1: Aadhar, 2: Bank, null: none

  final TextEditingController _panController = TextEditingController();
  final TextEditingController _aadharController = TextEditingController();
  final TextEditingController _accountController = TextEditingController();

  String? _panError;
  String? _aadharError;
  String? _accountError;

  String? _panFileName;
  String? _aadharFileName;
  String? _bankFileName;

  Future<void> _pickFile(int index) async {
    try {
      final result = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png', 'pdf'],
      );

      if (result != null && result.files.isNotEmpty) {
        setState(() {
          final fileName = result.files.single.name;
          if (index == 0) {
            _panFileName = fileName;
          } else if (index == 1) {
            _aadharFileName = fileName;
          } else if (index == 2) {
            _bankFileName = fileName;
          }
        });
      }
    } catch (e) {
      debugPrint('Error picking file: $e');
    }
  }

  @override
  void dispose() {
    _panController.dispose();
    _aadharController.dispose();
    _accountController.dispose();
    super.dispose();
  }

  bool _validatePan(String value) {
    if (value.isEmpty) {
      _panError = 'PAN number is required';
      return false;
    }
    final panRegex = RegExp(r'^[A-Z]{5}[0-9]{4}[A-Z]$');
    if (!panRegex.hasMatch(value)) {
      _panError =
          'Invalid PAN format. Pattern: 5 letters, 4 digits, 1 letter (e.g. ABCDE1234F)';
      return false;
    }
    _panError = null;
    return true;
  }

  bool _validateAadhar(String value) {
    final cleanValue = value.replaceAll(RegExp(r'\D'), '');
    if (cleanValue.isEmpty) {
      _aadharError = 'Aadhar number is required';
      return false;
    }
    if (cleanValue.length != 12) {
      _aadharError = 'Aadhar number must be exactly 12 digits';
      return false;
    }
    _aadharError = null;
    return true;
  }

  bool _validateAccount(String value) {
    if (value.isEmpty) {
      _accountError = 'Account number is required';
      return false;
    }
    final digitRegex = RegExp(r'^[0-9]+$');
    if (!digitRegex.hasMatch(value)) {
      _accountError = 'Account number must contain only numbers';
      return false;
    }
    _accountError = null;
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        scrolledUnderElevation: 0.5,
        leading: IconButton(
          icon: const Padding(
            padding: EdgeInsets.only(top: 4.0),
            child: Icon(Icons.arrow_back, color: Color(0xFF31378D)),
          ),
          onPressed: () => Navigator.maybePop(context),
        ),
        title: Text(
          'KYC Verification',
          style: GoogleFonts.poppins(
            color: const Color(0xFF31378D),
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        centerTitle: false,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  physics: const ClampingScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Why KYC? Banner
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFAF5FF), // Light violet bg
                          border: Border.all(
                            color: const Color(0xFF31378D),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Image.asset(
                              'assets/profile/bulb.png',
                              width: 28,
                              height: 28,
                              fit: BoxFit.contain,
                              errorBuilder: (context, error, stackTrace) =>
                                  const Icon(
                                    Icons.lightbulb_rounded,
                                    color: Color(
                                      0xFFFFB800,
                                    ), // Yellow bulb fallback
                                    size: 28,
                                  ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Why KYC?',
                                    style: GoogleFonts.poppins(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      color: const Color(0xFF0F172A),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'KYC (Know Your Customer) is the process of verifying a customer\'s identity to prevent fraud and ensure legal compliance.',
                                    style: GoogleFonts.poppins(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w400,
                                      color: const Color(0xFF475569),
                                      height: 1.4,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Documentation header
                      Text(
                        'KYC Documentation',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFF263238),
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Document Tiles (Accordion structure)
                      _buildDocCard(
                        index: 0,
                        title: 'PAN Card Details',
                        labelText: 'PAN Number',
                        hintText: 'Enter PAN number',
                        uploadLabel: 'Upload PAN Card',
                        uploadDesc: 'Click to upload PAN card',
                        controller: _panController,
                        errorText: _panError,
                        textCapitalization: TextCapitalization.characters,
                        inputFormatters: [PanTextInputFormatter()],
                        onChanged: (val) {
                          if (_panError != null) {
                            setState(() {
                              _validatePan(val);
                            });
                          }
                        },
                      ),
                      _buildDocCard(
                        index: 1,
                        title: 'Aadhar Card Details',
                        labelText: 'Aadhar Number',
                        hintText: 'Enter Aadhar number',
                        uploadLabel: 'Upload Aadhar Card',
                        uploadDesc: 'Click to upload Aadhar card',
                        controller: _aadharController,
                        errorText: _aadharError,
                        keyboardType: TextInputType.number,
                        inputFormatters: [AadharTextInputFormatter()],
                        onChanged: (val) {
                          if (_aadharError != null) {
                            setState(() {
                              _validateAadhar(val);
                            });
                          }
                        },
                      ),
                      _buildDocCard(
                        index: 2,
                        title: 'Bank Details',
                        labelText: 'Account Number',
                        hintText: 'Enter Account number',
                        uploadLabel: 'Upload Bank Password',
                        uploadDesc: 'Click to upload Bank Passbook',
                        controller: _accountController,
                        errorText: _accountError,
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        onChanged: (val) {
                          if (_accountError != null) {
                            setState(() {
                              _validateAccount(val);
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),

              // Bottom Section
              Padding(
                padding: const EdgeInsets.only(top: 32, bottom: 24),
                child: Column(
                  children: [
                    Text(
                      'Your data is secure and used only for verification',
                      style: GoogleFonts.poppins(
                        fontSize: 9,
                        fontWeight: FontWeight.w400,
                        color: const Color(0xFF525656),
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 32),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            final bool isPanValid = _validatePan(
                              _panController.text,
                            );
                            final bool isAadharValid = _validateAadhar(
                              _aadharController.text,
                            );
                            final bool isAccountValid = _validateAccount(
                              _accountController.text,
                            );

                            if (isPanValid && isAadharValid && isAccountValid) {
                              showSectorSelectionBottomSheet(
                                context,
                                onSuccess: () {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        'Verification Submitted Successfully!',
                                      ),
                                      backgroundColor: Colors.green,
                                    ),
                                  );
                                },
                              );
                            } else {
                              // Expand the first invalid card so the user sees the error
                              if (!isPanValid) {
                                _expandedIndex = 0;
                              } else if (!isAadharValid) {
                                _expandedIndex = 1;
                              } else if (!isAccountValid) {
                                _expandedIndex = 2;
                              }
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    'Please correct the errors in the form',
                                  ),
                                  backgroundColor: Colors.redAccent,
                                ),
                              );
                            }
                          });
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF31378D),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 0,
                        ),
                        child: Text(
                          'Submit',
                          style: GoogleFonts.poppins(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDocCard({
    required int index,
    required String title,
    required String labelText,
    required String hintText,
    required String uploadLabel,
    required String uploadDesc,
    required TextEditingController controller,
    required String? errorText,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    TextCapitalization textCapitalization = TextCapitalization.none,
    void Function(String)? onChanged,
  }) {
    final bool isExpanded = _expandedIndex == index;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Tab
          InkWell(
            onTap: () {
              setState(() {
                _expandedIndex = isExpanded ? null : index;
              });
            },
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Row(
                children: [
                  Image.asset(
                    'assets/profile/kyc_doc_emoji.png',
                    width: 21,
                    height: 21,
                    fit: BoxFit.contain,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      title,
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: const Color(0xFF000000),
                        height: 1.0,
                        letterSpacing: 0.0,
                      ),
                    ),
                  ),
                  Icon(
                    isExpanded
                        ? Icons.keyboard_arrow_down_rounded
                        : Icons.chevron_right_rounded,
                    color: const Color(0xFF0F172A),
                    size: 28,
                  ),
                ],
              ),
            ),
          ),

          // Expanded Content Area
          if (isExpanded)
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, bottom: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Text field label
                  Text(
                    labelText,
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Text field
                  Container(
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: errorText != null
                            ? const Color(0xFFEF4444)
                            : const Color(0xFF31378D),
                        width: 1.2,
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    alignment: Alignment.centerLeft,
                    child: TextField(
                      controller: controller,
                      keyboardType: keyboardType,
                      inputFormatters: inputFormatters,
                      textCapitalization: textCapitalization,
                      onChanged: onChanged,
                      style: GoogleFonts.poppins(
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        color: const Color(0xFF0F172A),
                      ),
                      decoration: InputDecoration(
                        hintText: hintText,
                        hintStyle: GoogleFonts.poppins(
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                          color: const Color(0xFF94A3B8),
                        ),
                        border: InputBorder.none,
                        isDense: true,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ),
                  if (errorText != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      errorText,
                      style: GoogleFonts.poppins(
                        fontSize: 10,
                        fontWeight: FontWeight.w400,
                        color: const Color(0xFFEF4444),
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),

                  // Upload Label
                  Text(
                    uploadLabel,
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Upload box
                  Builder(
                    builder: (context) {
                      String? selectedFileName;
                      if (index == 0) {
                        selectedFileName = _panFileName;
                      } else if (index == 1) {
                        selectedFileName = _aadharFileName;
                      } else if (index == 2) {
                        selectedFileName = _bankFileName;
                      }

                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: selectedFileName != null
                            ? null
                            : () => _pickFile(index),
                        child: CustomPaint(
                          painter: DashedRectPainter(
                            color: selectedFileName != null
                                ? const Color(0xFF10B981)
                                : const Color(0xFF94A3B8),
                            gap: 4.0,
                          ),
                          child: Container(
                            width: double.infinity,
                            height: 130,
                            alignment: Alignment.center,
                            child: selectedFileName != null
                                ? Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const Icon(
                                          Icons.insert_drive_file_rounded,
                                          color: Color(0xFF10B981),
                                          size: 36,
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          selectedFileName,
                                          style: GoogleFonts.poppins(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w500,
                                            color: const Color(0xFF0F172A),
                                          ),
                                          textAlign: TextAlign.center,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 8),
                                        InkWell(
                                          onTap: () {
                                            setState(() {
                                              if (index == 0) {
                                                _panFileName = null;
                                              } else if (index == 1) {
                                                _aadharFileName = null;
                                              } else if (index == 2) {
                                                _bankFileName = null;
                                              }
                                            });
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 8,
                                              vertical: 4,
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                const Icon(
                                                  Icons.delete_outline_rounded,
                                                  color: Color(0xFFEF4444),
                                                  size: 16,
                                                ),
                                                const SizedBox(width: 4),
                                                Text(
                                                  'Remove file',
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 11,
                                                    fontWeight: FontWeight.w500,
                                                    color: const Color(
                                                      0xFFEF4444,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                : Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Icon(
                                        Icons.upload_outlined,
                                        color: Color(0xFF64748B),
                                        size: 26,
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        uploadDesc,
                                        style: GoogleFonts.poppins(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w500,
                                          color: const Color(0xFF475569),
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        'JPG, PNG or PDF (Max 5MB)',
                                        style: GoogleFonts.poppins(
                                          fontSize: 9,
                                          fontWeight: FontWeight.w400,
                                          color: const Color(0xFF94A3B8),
                                        ),
                                      ),
                                    ],
                                  ),
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }


}

class DashedRectPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  final double gap;

  DashedRectPainter({
    this.color = const Color(0xFF94A3B8),
    this.strokeWidth = 1.0,
    this.gap = 4.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;

    final Path path = Path();
    path.addRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.width, size.height),
        const Radius.circular(8),
      ),
    );

    final Path dashedPath = Path();
    double distance = 0.0;
    for (final PathMetric measure in path.computeMetrics()) {
      while (distance < measure.length) {
        dashedPath.addPath(
          measure.extractPath(distance, distance + gap),
          Offset.zero,
        );
        distance += gap * 2;
      }
    }
    canvas.drawPath(dashedPath, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class PanTextInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final text = newValue.text;
    final buffer = StringBuffer();
    int acceptedBeforeCursor = 0;

    for (int i = 0; i < text.length; i++) {
      final char = text[i];
      final currentLength = buffer.length;
      bool isValid = false;

      if (currentLength < 5) {
        // Must be a letter
        if (RegExp(r'[a-zA-Z]').hasMatch(char)) {
          buffer.write(char.toUpperCase());
          isValid = true;
        }
      } else if (currentLength < 9) {
        // Must be a number
        if (RegExp(r'[0-9]').hasMatch(char)) {
          buffer.write(char);
          isValid = true;
        }
      } else if (currentLength == 9) {
        // Must be a letter
        if (RegExp(r'[a-zA-Z]').hasMatch(char)) {
          buffer.write(char.toUpperCase());
          isValid = true;
        }
      }

      if (isValid && i < newValue.selection.end) {
        acceptedBeforeCursor++;
      }
    }

    final newText = buffer.toString();

    return TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: acceptedBeforeCursor),
    );
  }
}

class AadharTextInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final text = newValue.text;

    // Extract only the digits from the input
    final digits = text.replaceAll(RegExp(r'\D'), '');

    // Limit digits to maximum of 12
    final limitedDigits = digits.length > 12 ? digits.substring(0, 12) : digits;

    // Format digits with 2 spaces gap after every 4 digits
    final buffer = StringBuffer();
    for (int i = 0; i < limitedDigits.length; i++) {
      buffer.write(limitedDigits[i]);
      if ((i == 3 || i == 7) && i != limitedDigits.length - 1) {
        buffer.write('  '); // 2 spaces gap
      }
    }

    final formattedText = buffer.toString();

    // Calculate cursor offset in terms of digits before cursor
    int selectionIndex = newValue.selection.end;
    int digitsBeforeCursor = 0;
    for (int i = 0; i < selectionIndex && i < text.length; i++) {
      if (RegExp(r'[0-9]').hasMatch(text[i])) {
        digitsBeforeCursor++;
      }
    }

    // Limit digits before cursor to 12
    if (digitsBeforeCursor > 12) {
      digitsBeforeCursor = 12;
    }

    // Simple mathematical mapping from digits count to cursor position including spaces
    int targetCursorOffset = digitsBeforeCursor;
    if (digitsBeforeCursor > 4) {
      targetCursorOffset += 2;
    }
    if (digitsBeforeCursor > 8) {
      targetCursorOffset += 2;
    }

    return TextEditingValue(
      text: formattedText,
      selection: TextSelection.collapsed(offset: targetCursorOffset),
    );
  }
}
