import 'package:tm/fast_page_route.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../api_services/profile_api_service.dart';
import 'help_center.dart';
import 'kyc_verification.dart';
import 'terms_of_service.dart';
import 'personal_info.dart';
import 'subscription_plan.dart';
import '../login/login_screen.dart';

class ProfileScreen extends StatefulWidget {
  final bool showBackButton;

  const ProfileScreen({super.key, this.showBackButton = true});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _pushNotifications = true;
  bool _emailNotifications = true;
  String _name = 'Mohan';
  String? _profileImage;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (mounted) {
        setState(() {
          _name = prefs.getString('name') ?? 'Mohan';
          _profileImage = prefs.getString('profile_image');
        });
      }

      final response = await ProfileApiService.fetchProfile();
      if (response != null && mounted) {
        setState(() {
          _name = prefs.getString('name') ?? 'Mohan';
          _profileImage = prefs.getString('profile_image');
        });
      }
    } catch (e) {
      debugPrint('Error loading profile: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header Stack ────────────────────────────────────────────────
            SizedBox(
              height: 300,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  // Blue Gradient Header Background
                  Container(
                    height: 250,
                    width: double.infinity,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF1E3A8A), Color(0xFF1644C8)],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(32),
                        bottomRight: Radius.circular(32),
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: SafeArea(
                      bottom: false,
                      child: Column(
                        children: [
                          const SizedBox(height: 10),
                          // Back Arrow and Action Row
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              if (widget.showBackButton)
                                GestureDetector(
                                  onTap: () => Navigator.maybePop(context),
                                  child: const Icon(
                                    Icons.arrow_back,
                                    color: Colors.white,
                                    size: 24,
                                  ),
                                )
                              else
                                const SizedBox(width: 24),
                              const SizedBox(width: 24), // Spacer to balance
                            ],
                          ),
                          const SizedBox(height: 6),
                          // Avatar
                          Stack(
                            alignment: Alignment.bottomRight,
                            children: [
                              Container(
                                width: 90,
                                height: 90,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white,
                                    width: 3.0,
                                  ),
                                ),
                                child: ClipOval(
                                  child: (_profileImage != null && _profileImage!.startsWith('http'))
                                      ? Image.network(
                                          _profileImage!,
                                          fit: BoxFit.cover,
                                          errorBuilder: (context, error, stackTrace) => Image.asset(
                                            'assets/home/mohan_profile.png',
                                            fit: BoxFit.cover,
                                          ),
                                        )
                                      : Image.asset(
                                          'assets/home/mohan_profile.png',
                                          fit: BoxFit.cover,
                                        ),
                                ),
                              ),
                              // Verified Checkmark Badge
                              Container(
                                padding: const EdgeInsets.all(2),
                                decoration: const BoxDecoration(
                                  color: Colors.green,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.verified,
                                  color: Colors.white,
                                  size: 20,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          // Name
                          Text(
                            _name,
                            style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 8),
                          // Premium Buyer Badge
                          Container(
                            width: 220,
                            height: 28,
                            decoration: BoxDecoration(
                              color: const Color(0x33D9D9D9),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            padding: const EdgeInsets.only(
                              top: 7,
                              right: 13,
                              bottom: 7,
                              left: 13,
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              'Premium Buyer - Borrower',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.lato(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFFFFFFFF),
                                height: 1.0,
                                letterSpacing: 0.0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Overlay Stats Card
                  Positioned(
                    top: 220,
                    left: 20,
                    right: 20,
                    child: Container(
                      height: 70,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: const Color(0xFFE2E8F0),
                          width: 1,
                        ),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x0D000000),
                            blurRadius: 16,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _buildStatColumn('740', 'Credit Score'),
                          _buildStatColumn('Verified', 'KYC Status'),
                          _buildStatColumn('3', 'Requests'),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // ── Settings List ───────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Account Settings',
                    style: GoogleFonts.poppins(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF7C3AED), // Violet theme
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Account Settings Card
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: const Color(0xFFE2E8F0),
                        width: 1.2,
                      ),
                    ),
                    child: Column(
                      children: [
                        _buildSettingsTile(
                          imagePath: 'assets/profile/person_kyc.png',
                          title: 'Personal Information',
                          trailing: const Icon(
                            Icons.chevron_right_rounded,
                            color: Color(0xFF475569),
                            size: 26,
                          ),
                          onTap: () async {
                            final updated = await Navigator.of(context).push(
                              FastPageRoute(
                                child: const PersonalInfoScreen(),
                              ),
                            );
                            if (updated == true) {
                              _loadProfile();
                            }
                          },
                        ),
                        const _Divider(),
                        _buildSettingsTile(
                          imagePath: 'assets/profile/person_kyc.png',
                          title: 'KYC verification',
                          trailing: const Icon(
                            Icons.chevron_right_rounded,
                            color: Color(0xFF475569),
                            size: 26,
                          ),
                          onTap: () {
                            Navigator.of(context).push(
                              FastPageRoute(
                                child: const KycVerificationScreen(),
                              ),
                            );
                          },
                        ),
                        const _Divider(),
                        _buildSettingsTile(
                          imagePath: 'assets/profile/push_notifi.png',
                          title: 'Push Notifications',
                          trailing: Transform.translate(
                            offset: const Offset(6, 0),
                            child: SizedBox(
                              height: 32,
                              child: Switch(
                                materialTapTargetSize:
                                    MaterialTapTargetSize.shrinkWrap,
                                value: _pushNotifications,
                                onChanged: (val) =>
                                    setState(() => _pushNotifications = val),
                                activeThumbColor: Colors.white,
                                activeTrackColor: const Color(0xFF22C55E),
                                inactiveThumbColor: Colors.white,
                                inactiveTrackColor: const Color(0xFFE2E8F0),
                              ),
                            ),
                          ),
                        ),
                        const _Divider(),
                        _buildSettingsTile(
                          imagePath: 'assets/profile/email_notifi.png',
                          title: 'Email Notifications',
                          trailing: Transform.translate(
                            offset: const Offset(6, 0),
                            child: SizedBox(
                              height: 32,
                              child: Switch(
                                materialTapTargetSize:
                                    MaterialTapTargetSize.shrinkWrap,
                                value: _emailNotifications,
                                onChanged: (val) =>
                                    setState(() => _emailNotifications = val),
                                activeThumbColor: Colors.white,
                                activeTrackColor: const Color(0xFF22C55E),
                                inactiveThumbColor: Colors.white,
                                inactiveTrackColor: const Color(0xFFE2E8F0),
                              ),
                            ),
                          ),
                        ),
                        const _Divider(),
                        _buildSettingsTile(
                          imagePath: 'assets/profile/dark_mode.png',
                          title: 'Dark Mode',
                          trailing: const Icon(
                            Icons.chevron_right_rounded,
                            color: Color(0xFF475569),
                            size: 26,
                          ),
                        ),
                        const _Divider(),
                        _buildSettingsTile(
                          imagePath: 'assets/profile/subscription.png',
                          title: 'Subcription plan',
                          trailing: const Icon(
                            Icons.chevron_right_rounded,
                            color: Color(0xFF475569),
                            size: 26,
                          ),
                          onTap: () {
                            Navigator.of(context).push(
                              FastPageRoute(
                                child: const SubscriptionPlanScreen(),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  Text(
                    'Support',
                    style: GoogleFonts.poppins(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Support Card
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: const Color(0xFFE2E8F0),
                        width: 1.2,
                      ),
                    ),
                    child: Column(
                      children: [
                        _buildSupportTile(
                          imagePath: 'assets/profile/help_center.png',
                          title: 'Help Center',
                          isRed: false,
                          onTap: () {
                            Navigator.of(context).push(
                              FastPageRoute(
                                child: const HelpCenterScreen(),
                              ),
                            );
                          },
                        ),
                        const _Divider(),
                        _buildSupportTile(
                          imagePath: 'assets/profile/terms_and _service.png',
                          title: 'Terms of Service',
                          isRed: false,
                          onTap: () {
                            Navigator.of(context).push(
                              FastPageRoute(
                                child: const TermsOfServiceScreen(),
                              ),
                            );
                          },
                        ),
                        const _Divider(),
                        _buildSupportTile(
                          imagePath: 'assets/profile/logout.png',
                          title: 'Log Out',
                          isRed: true,
                          onTap: () async {
                            final navigator = Navigator.of(context);
                            final prefs = await SharedPreferences.getInstance();
                            await prefs.clear();
                            navigator.pushAndRemoveUntil(
                              FastPageRoute(
                                child: const LoginScreen(),
                              ),
                              (route) => false,
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 100), // Spacing for bottom nav bar
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatColumn(String val, String label) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          val,
          style: GoogleFonts.poppins(
            fontSize: 15,
            fontWeight: FontWeight.w700,
            color: const Color(0xFF1B8A3D), // Green stats
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 12,
            color: const Color(0xFF525656),
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }

  Widget _buildSettingsTile({
    required String imagePath,
    required String title,
    required Widget trailing,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            Image.asset(imagePath, width: 32, height: 32, fit: BoxFit.contain),
            const SizedBox(width: 12),
            Text(
              title,
              style: GoogleFonts.poppins(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: const Color(0xFF1E293B),
              ),
            ),
            const Spacer(),
            trailing,
          ],
        ),
      ),
    );
  }

  Widget _buildSupportTile({
    required String imagePath,
    required String title,
    required bool isRed,
    VoidCallback? onTap,
  }) {
    final Color itemColor = isRed
        ? const Color(0xFFEF4444)
        : const Color(0xFF1E293B);
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Image.asset(imagePath, width: 24, height: 24, fit: BoxFit.contain),
            const SizedBox(width: 12),
            Text(
              title,
              style: GoogleFonts.poppins(
                fontSize: 14.64,
                fontWeight: FontWeight.w400,
                color: itemColor,
                height: 1.5,
                letterSpacing: 0.0,
              ),
            ),
            const Spacer(),
            if (!isRed)
              const Icon(
                Icons.chevron_right_rounded,
                color: Color(0xFF475569),
                size: 26,
              ),
          ],
        ),
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  const _Divider();

  @override
  Widget build(BuildContext context) {
    return const Divider(height: 1, thickness: 1, color: Color(0xFFF1F5F9));
  }
}
