import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../home/main_navigation.dart';

// ── Bank Offer Data Model ────────────────────────────────────────────────────
class BankOfferData {
  final String bankName;
  final String logoText;
  final Color logoBgColor;
  final Color logoTextColor;
  final String interestRate;
  final String loanAmount;
  final String tenure;
  final String maxLoanAmount;
  final String maxLoanFormatted;

  const BankOfferData({
    required this.bankName,
    required this.logoText,
    required this.logoBgColor,
    required this.logoTextColor,
    required this.interestRate,
    required this.loanAmount,
    required this.tenure,
    required this.maxLoanAmount,
    required this.maxLoanFormatted,
  });
}

// ── Predefined Bank Data ─────────────────────────────────────────────────────
const List<BankOfferData> bankOffers = [
  BankOfferData(
    bankName: 'HDFC BANK',
    logoText: 'HDFC',
    logoBgColor: Color(0xFFFFFFFF),
    logoTextColor: Color(0xFF0C3C96),
    interestRate: '10.50% p.a.',
    loanAmount: '₹25 Lakhs',
    tenure: '60 months',
    maxLoanAmount: '₹25,00,000',
    maxLoanFormatted: '25,00,000',
  ),
  BankOfferData(
    bankName: 'SBI BANK',
    logoText: 'SBI',
    logoBgColor: Color(0xFFFFFFFF),
    logoTextColor: Color(0xFF00A2E8),
    interestRate: '10.25% p.a.',
    loanAmount: '₹20 Lakhs',
    tenure: '48 months',
    maxLoanAmount: '₹20,00,000',
    maxLoanFormatted: '20,00,000',
  ),
  BankOfferData(
    bankName: 'ICICI BANK',
    logoText: 'ICICI',
    logoBgColor: Color(0xFFFFFFFF),
    logoTextColor: Color(0xFFE58023),
    interestRate: '10.75% p.a.',
    loanAmount: '₹30 Lakhs',
    tenure: '72 months',
    maxLoanAmount: '₹30,00,000',
    maxLoanFormatted: '30,00,000',
  ),
];

// ── Helper to find bank data by name ─────────────────────────────────────────
BankOfferData getBankOfferByName(String bankName) {
  final lower = bankName.toLowerCase();
  if (lower.contains('hdfc')) return bankOffers[0];
  if (lower.contains('sbi')) return bankOffers[1];
  if (lower.contains('icic')) return bankOffers[2];
  return bankOffers[0]; // Default to HDFC
}

// ── Show Bank Offer Dialog (Centered on screen) ─────────────────────────────
void showBankOfferDialog(BuildContext context, BankOfferData bank) {
  showDialog(
    context: context,
    barrierDismissible: true,
    barrierColor: Colors.black.withValues(alpha: 0.5),
    builder: (context) => Center(
      child: Material(
        color: Colors.transparent,
        child: _BankOfferCard(bank: bank),
      ),
    ),
  );
}

class _BankOfferCard extends StatelessWidget {
  final BankOfferData bank;
  const _BankOfferCard({required this.bank});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final cardWidth = screenWidth - 40;

    return Container(
      width: cardWidth,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.15),
            blurRadius: 30,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Dark Navy Header with Bank Logo ─────────────────────────
          _buildHeader(context),

          // ── Card Body ───────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
            child: Column(
              children: [
                // Bank Name
                Text(
                  bank.bankName,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xFF7F8C8D),
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 6),

                // Title
                Text(
                  'Exclusive Personal Loan Offer',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF1A1A2E),
                    height: 1.3,
                  ),
                ),
                const SizedBox(height: 20),

                // Info Rows
                _buildInfoRow(
                  icon: Icons.percent_rounded,
                  iconBg: const Color(0xFF2E7D6F),
                  label: 'Interest Rate',
                  value: 'Starting at ${bank.interestRate}',
                ),
                const SizedBox(height: 12),
                _buildInfoRow(
                  icon: Icons.account_balance_wallet_rounded,
                  iconBg: const Color(0xFF1A3A5C),
                  label: 'Loan Amount',
                  value: 'Up to ${bank.loanAmount}',
                ),
                const SizedBox(height: 12),
                _buildInfoRow(
                  icon: Icons.calendar_today_rounded,
                  iconBg: const Color(0xFF4A5568),
                  label: 'Flexible Tenure',
                  value: 'Up to ${bank.tenure}',
                ),
                const SizedBox(height: 24),

                // View More Button
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context); // Close dialog
                    Navigator.push(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation, secondaryAnimation) =>
                            BankVisitDetailScreen(bank: bank),
                        transitionsBuilder:
                            (context, animation, secondaryAnimation, child) {
                              const begin = Offset(1.0, 0.0);
                              const end = Offset.zero;
                              const curve = Curves.easeInOut;
                              var tween = Tween(
                                begin: begin,
                                end: end,
                              ).chain(CurveTween(curve: curve));
                              return SlideTransition(
                                position: animation.drive(tween),
                                child: child,
                              );
                            },
                        transitionDuration: const Duration(milliseconds: 400),
                      ),
                    );
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF00033F),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    alignment: Alignment.center,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'View More',
                          style: GoogleFonts.poppins(
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Icon(
                          Icons.arrow_forward,
                          color: Colors.white,
                          size: 24,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),

                // Maybe Later
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Text(
                    'MAYBE LATER',
                    style: GoogleFonts.manrope(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFF454651),
                      letterSpacing: 1.07,
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Verified Footer
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.verified,
                      color: Color(0xFF006C4B),
                      size: 18,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Verified TrueLoan Partner Offer',
                      style: GoogleFonts.manrope(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF454651),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 100,
      decoration: const BoxDecoration(
        color: Color(0xFF00033F),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // Close button
          Positioned(
            top: 12,
            right: 12,
            child: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.close, color: Colors.white, size: 16),
              ),
            ),
          ),
          // Bank Logo (positioned to hang below the header)
          Positioned(
            bottom: 10,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: bank.logoBgColor,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFE0E0E0), width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                alignment: Alignment.center,
                child: Text(
                  bank.logoText,
                  style: GoogleFonts.poppins(
                    fontSize: bank.logoText.length > 4 ? 10 : 12,
                    fontWeight: FontWeight.w800,
                    color: bank.logoTextColor,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required Color iconBg,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F8FA),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFEEF2F6), width: 1),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.poppins(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF454651),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: const Color(0xFF191C1D),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// ── Bank Visit Detail Screen (Full-page scrollable) ──────────────────────────
// ══════════════════════════════════════════════════════════════════════════════
class BankVisitDetailScreen extends StatelessWidget {
  final BankOfferData bank;
  const BankVisitDetailScreen({super.key, required this.bank});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB),
      appBar: AppBar(
        backgroundColor: const Color(0xFF00033F),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Visit Detail',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        centerTitle: false,
      ),
      body: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Bank Header Card ─────────────────────────────────
            _buildBankHeaderCard(),
            const SizedBox(height: 16),

            // ── Max Loan Amount Card ──────────────────────────────
            _buildMaxLoanCard(),
            const SizedBox(height: 16),

            // ── Interest Rate & Tenure Row ────────────────────────
            _buildRateTenureRow(),
            const SizedBox(height: 24),

            // ── Features & Benefits ───────────────────────────────
            _buildFeaturesSection(),
            const SizedBox(height: 24),

            // ── Eligibility Check ─────────────────────────────────
            _buildEligibilitySection(),
            const SizedBox(height: 24),

            // ── EMI Example ───────────────────────────────────────
            _buildEmiExampleSection(),
            const SizedBox(height: 20),

            // ── Bottom Section (Apply Now) ────────────────────────
            _buildBottomSection(context),
          ],
        ),
      ),
    );
  }

  Widget _buildBankHeaderCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // Bank Logo
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: bank.logoBgColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE0E0E0), width: 1.5),
            ),
            alignment: Alignment.center,
            child: Text(
              bank.logoText,
              style: GoogleFonts.poppins(
                fontSize: bank.logoText.length > 4 ? 9 : 11,
                fontWeight: FontWeight.w800,
                color: bank.logoTextColor,
              ),
            ),
          ),
          const SizedBox(width: 14),

          // Bank Name + Subtitle
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${bank.bankName.split(' ').first.substring(0, 1).toUpperCase()}${bank.bankName.split(' ').first.substring(1).toLowerCase()} Bank',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF1A1A2E),
                  ),
                ),
                Text(
                  'Personal Loan Offer',
                  style: GoogleFonts.poppins(
                    fontSize: 9,
                    color: const Color(0xFF7F8C8D),
                  ),
                ),
              ],
            ),
          ),

          // Pre-Approved Badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFFE6FFF5),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF72F8BF), width: 1),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.check, color: Color(0xFF00714E), size: 12),
                const SizedBox(width: 4),
                Text(
                  'Pre-Approved',
                  style: GoogleFonts.poppins(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF00714E),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMaxLoanCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF00033F),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF00033F).withValues(alpha: 0.3),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Maximum Loan Amount',
            style: GoogleFonts.poppins(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: Colors.white.withValues(alpha: 0.7),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            bank.maxLoanAmount,
            style: GoogleFonts.manrope(
              fontSize: 28,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.1,
            ),
          ),
          const SizedBox(height: 16),
          // Chips
          Row(
            children: [
              _buildChip('Quick Approval'),
              const SizedBox(width: 10),
              _buildChip('Paperless'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildChip(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.25),
          width: 1,
        ),
      ),
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: 11,
          fontWeight: FontWeight.w500,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget _buildRateTenureRow() {
    // Parse rate number for display
    final rateNumber = bank.interestRate.replaceAll(' p.a.', '');
    // Parse tenure number
    final tenureText = bank.tenure;

    return Row(
      children: [
        // Interest Rate Card
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: const Color(0xFF302000),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Interest Rate',
                  style: GoogleFonts.manrope(
                    fontSize: 10,
                    fontWeight: FontWeight.w400,
                    color: Color(0xffB18210),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  rateNumber,
                  style: GoogleFonts.manrope(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Color(0xffB18210),
                    height: 1.1,
                  ),
                ),
                Text(
                  'per annum',
                  style: GoogleFonts.manrope(
                    fontSize: 10,
                    color: Color(0xffB18210),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 14),

        // Tenure Card
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: const Color(0xFFF5F3ED),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFE8E4D8), width: 1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Tenure',
                  style: GoogleFonts.poppins(
                    fontSize: 11,
                    fontWeight: FontWeight.w400,
                    color: const Color(0xFF7F8C8D),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Up to ${tenureText.split(' ').first}',
                  style: GoogleFonts.poppins(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF1A1A2E),
                    height: 1.1,
                  ),
                ),
                Text(
                  'Months',
                  style: GoogleFonts.poppins(
                    fontSize: 11,
                    color: const Color(0xFF7F8C8D),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFeaturesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Features & Benefits',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF1A1A2E),
          ),
        ),
        const SizedBox(height: 16),
        _buildFeatureItem(
          Icons.flash_on_rounded,
          'Instant Disbursal',
          'Funds credited to your account in 10 mins.',
        ),
        const SizedBox(height: 14),
        _buildFeatureItem(
          Icons.description_outlined,
          'Paperless Process',
          '100% digital journey, no physical docs needed.',
        ),
        const SizedBox(height: 14),
        _buildFeatureItem(
          Icons.visibility_off_outlined,
          'No Hidden Charges',
          'Transparent processing fees and zero loan trap.',
        ),
      ],
    );
  }

  Widget _buildFeatureItem(IconData icon, String title, String subtitle) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFEEF2F6)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: const Color(0xFFE8F0FE),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: const Color(0xFF00033F), size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF1A1A2E),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.poppins(
                    fontSize: 11,
                    color: const Color(0xFF7F8C8D),
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEligibilitySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Eligibility Check',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF1A1A2E),
          ),
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _buildEligibilityChip(
              Icons.currency_rupee,
              'Monthly Income > ₹25,000',
            ),
            _buildEligibilityChip(
              Icons.person_outline,
              'Age between 21 - 60 years',
            ),
            _buildEligibilityChip(
              Icons.work_outline,
              'Employment at Registered Org.',
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildEligibilityChip(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE0E4E8)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: const Color(0xFF03C68A)),
          const SizedBox(width: 8),
          Text(
            text,
            style: GoogleFonts.poppins(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: const Color(0xFF1A1A2E),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmiExampleSection() {
    // EMI data varies by bank
    final emiData = _getEmiData();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'EMI Example',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF1A1A2E),
          ),
        ),
        const SizedBox(height: 14),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFEEF2F6)),
          ),
          child: Column(
            children: [
              // Table Header
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                decoration: const BoxDecoration(
                  color: Color(0xFF00033F),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Text(
                        'Loan Amount',
                        style: GoogleFonts.poppins(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        'Tenure',
                        style: GoogleFonts.poppins(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        'EMI',
                        style: GoogleFonts.poppins(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                        textAlign: TextAlign.right,
                      ),
                    ),
                  ],
                ),
              ),
              // Table Rows
              ...emiData.asMap().entries.map((entry) {
                final isLast = entry.key == emiData.length - 1;
                final row = entry.value;
                return Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    border: isLast
                        ? null
                        : const Border(
                            bottom: BorderSide(color: Color(0xFFEEF2F6)),
                          ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Text(
                          row['amount']!,
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: const Color(0xFF1A1A2E),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Text(
                          row['tenure']!,
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            color: const Color(0xFF7F8C8D),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Text(
                          row['emi']!,
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF0050CC),
                          ),
                          textAlign: TextAlign.right,
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          '* EMI calculations are indicative and may vary.',
          style: GoogleFonts.poppins(
            fontSize: 10,
            color: const Color(0xFF7F8C8D),
            fontStyle: FontStyle.italic,
          ),
        ),
      ],
    );
  }

  List<Map<String, String>> _getEmiData() {
    if (bank.bankName.contains('HDFC')) {
      return [
        {'amount': '₹1,00,000', 'tenure': '60 Mo', 'emi': '₹2,149'},
        {'amount': '₹5,00,000', 'tenure': '60 Mo', 'emi': '₹10,745'},
      ];
    } else if (bank.bankName.contains('SBI')) {
      return [
        {'amount': '₹1,00,000', 'tenure': '48 Mo', 'emi': '₹2,540'},
        {'amount': '₹5,00,000', 'tenure': '48 Mo', 'emi': '₹12,700'},
      ];
    } else {
      return [
        {'amount': '₹1,00,000', 'tenure': '72 Mo', 'emi': '₹1,868'},
        {'amount': '₹5,00,000', 'tenure': '72 Mo', 'emi': '₹9,340'},
      ];
    }
  }

  Widget _buildBottomSection(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Apply Now Button
          GestureDetector(
            onTap: () {
              Navigator.pop(context); // Close visit detail
              Navigator.push(
                context,
                PageRouteBuilder(
                  pageBuilder: (context, animation, secondaryAnimation) =>
                      const MainNavigationScreen(
                        openCreateAd: true,
                        initialSelectedType: 0,
                      ),
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) {
                        const begin = Offset(1.0, 0.0);
                        const end = Offset.zero;
                        const curve = Curves.easeInOut;
                        var tween = Tween(
                          begin: begin,
                          end: end,
                        ).chain(CurveTween(curve: curve));
                        return SlideTransition(
                          position: animation.drive(tween),
                          child: child,
                        );
                      },
                  transitionDuration: const Duration(milliseconds: 400),
                ),
              );
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                color: const Color(0xFF00033F),
                borderRadius: BorderRadius.circular(16),
              ),
              alignment: Alignment.center,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Apply Now',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Icon(
                    Icons.arrow_forward,
                    color: Colors.white,
                    size: 20,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'By clicking Apply Now, you agree to the T&Cs.',
            style: GoogleFonts.poppins(
              fontSize: 10,
              color: const Color(0xFF7F8C8D),
            ),
          ),
        ],
      ),
    );
  }
}
