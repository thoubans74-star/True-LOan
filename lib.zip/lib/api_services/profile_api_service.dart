import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ProfileApiService {
  static const String baseUrl = 'https://trueloan.ai.in/ai/api/m_api/';

  /// Fetches profile details from the server using the type 1104 API
  static Future<Map<String, dynamic>?> fetchProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String userId = prefs.getString('user_id') ?? '33';
      final String deviceId = prefs.getString('device_id') ?? '5';
      final String lt = prefs.getString('lt') ?? '11';
      final String ln = prefs.getString('ln') ?? '11';

      final response = await http.post(
        Uri.parse(baseUrl),
        body: {
          'cid': '21472147',
          'ln': ln,
          'lt': lt,
          'user_id': '33',
          'type': '1104',
          'device_id': deviceId,
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        if (responseData['status'] == 'success' &&
            responseData['data'] != null) {
          final data = responseData['data'];
          // Cache the profile details
          await prefs.setString(
            'user_id',
            data['user_id']?.toString() ?? userId,
          );
          await prefs.setString('name', data['name'] ?? '');
          await prefs.setString('mobile', data['mobile'] ?? '');
          await prefs.setString('email', data['email'] ?? '');
          await prefs.setString('profile_image', data['profile_image'] ?? '');
          return responseData;
        }
      }
    } catch (e) {
      debugPrint('Error in fetchProfile: $e');
    }
    return null;
  }

  /// Updates profile details on the server using the type 1103 multipart/form-data API
  static Future<Map<String, dynamic>?> updateProfile({
    required String name,
    required String email,
    required String mobile,
    PlatformFile? pickedFile,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String userId = prefs.getString('user_id') ?? '33';
      final String deviceId = prefs.getString('device_id') ?? '13';
      final String lt = prefs.getString('lt') ?? '11';
      final String ln = prefs.getString('ln') ?? '11';

      final uri = Uri.parse(baseUrl);
      final request = http.MultipartRequest('POST', uri);

      request.fields.addAll({
        'cid': '21472147',
        'ln': ln,
        'lt': lt,
        'device_id': deviceId,
        'type': '1103',
        'mobile': mobile,
        'name': name,
        'email': email,
        'user_id': '33',
      });

      if (pickedFile != null) {
        if (kIsWeb) {
          if (pickedFile.bytes != null) {
            request.files.add(
              http.MultipartFile.fromBytes(
                'profile_image',
                pickedFile.bytes!,
                filename: pickedFile.name,
              ),
            );
          }
        } else {
          if (pickedFile.path != null) {
            request.files.add(
              await http.MultipartFile.fromPath(
                'profile_image',
                pickedFile.path!,
                filename: pickedFile.name,
              ),
            );
          }
        }
      }

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        if (responseData['status'] == 'success' &&
            responseData['data'] != null) {
          final data = responseData['data'];
          // Cache the updated profile details
          await prefs.setString(
            'user_id',
            data['user_id']?.toString() ?? userId,
          );
          await prefs.setString(
            'mobile',
            data['phone'] ?? data['mobile'] ?? mobile,
          );
          await prefs.setString('name', data['name'] ?? name);
          await prefs.setString('email', data['email'] ?? email);
          await prefs.setString('profile_image', data['profile_image'] ?? '');
          return responseData;
        }
      }
    } catch (e) {
      debugPrint('Error in updateProfile: $e');
    }
    return null;
  }
}
