import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:tm/profile/verification_sheets.dart';

class CreateAdScreen extends StatefulWidget {
  final int initialSelectedType;
  const CreateAdScreen({super.key, this.initialSelectedType = -1});

  @override
  State<CreateAdScreen> createState() => _CreateAdScreenState();
}

class _CreateAdScreenState extends State<CreateAdScreen> {
  int _selectedType = -1; // 0 = Need a Loan, 1 = Give a Loan
  bool _submitted = false;

  @override
  void initState() {
    super.initState();
    _selectedType = widget.initialSelectedType;
  }

  final _loanAmountController = TextEditingController(text: '₹ 500000');
  final _interestRateController = TextEditingController(text: '12');
  final _tenureController = TextEditingController(text: '24');
  final _purposeController = TextEditingController(
    text: 'Business, Education, Personal',
  );

  @override
  void dispose() {
    _loanAmountController.dispose();
    _interestRateController.dispose();
    _tenureController.dispose();
    _purposeController.dispose();
    super.dispose();
  }

  Future<void> _onSubmitTap() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black.withValues(alpha: 0.45),
      builder: (_) => const _SuccessBottomSheet(),
    );
    // After the sheet is dismissed, mark submitted
    if (mounted) setState(() => _submitted = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // ── Blue AppBar (Same header like marketplace) ──────────────────
          Container(
            color: const Color(0xFF004AC6),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(
                        Icons.arrow_back_rounded,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    Text(
                      'Create Advertisement',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Content ───────────────────────────────────────────────────
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Submitted success banner ───────────────────────────
                  if (_submitted) ...[
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEFFFF4),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // ── Left accent gradient bar ───────────────────
                            Container(
                              width: 5,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color(0xFF1B8A3D),
                                    Color(0xFF072410),
                                  ],
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                ),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(12),
                                  bottomLeft: Radius.circular(12),
                                ),
                              ),
                            ),
                            // ── Text content ──────────────────────────────
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 14,
                                ),
                                child: ShaderMask(
                                  shaderCallback: (bounds) =>
                                      const LinearGradient(
                                        colors: [
                                          Color(0xFF1B8A3D),
                                          Color(0xFF072410),
                                        ],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      ).createShader(bounds),
                                  blendMode: BlendMode.srcIn,
                                  child: RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: 'Ad submitted!\n',
                                          style: GoogleFonts.poppins(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                            height: 1.75,
                                            letterSpacing: 0,
                                            color: Colors.white,
                                          ),
                                        ),
                                        TextSpan(
                                          text:
                                              'Under review — usually approved within 24h.',
                                          style: GoogleFonts.poppins(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w500,
                                            height: 1.75,
                                            letterSpacing: 0,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],

                  // ── Loan Type Selector ─────────────────────────────────
                  Row(
                    children: [
                      Expanded(
                        child: _LoanTypeCard(
                          icon: 'assets/ads/need_a_loan.png',
                          label: 'Need a Loan',
                          isSelected: _selectedType == 0,
                          onTap: () => setState(() => _selectedType = 0),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _LoanTypeCard(
                          icon: 'assets/ads/give_a_loan.png',
                          label: 'Give a Loan',
                          isSelected: _selectedType == 1,
                          onTap: () {
                            showSectorSelectionBottomSheet(
                              context,
                              onSuccess: () {
                                setState(() => _selectedType = 1);
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // ── Form Fields (All same width) ───────────────────────
                  _FormField(
                    label: 'Loan Amount (₹)',
                    controller: _loanAmountController,
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 14),
                  _FormField(
                    label: 'Interest Rate (% p.a.)',
                    controller: _interestRateController,
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 14),
                  _FormField(
                    label: 'Tenure (months)',
                    controller: _tenureController,
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 14),
                  _FormField(label: 'Purpose', controller: _purposeController),

                  const SizedBox(height: 24),

                  // ── Submit Button ──────────────────────────────────────
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _onSubmitTap,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF004AC6),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 0,
                      ),
                      child: Text(
                        'Submit For Review',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),

                  if (_submitted) ...[
                    const SizedBox(height: 20),

                    // ── Create Advertisement section ───────────────────────
                    Text(
                      'Create Advertisement',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF000000),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // ── Ads in Progress button ─────────────────────────────
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        width: double.infinity,
                        height: 50,
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFF1B8A3D), Color(0xFF1ADB56)],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20),
                            topRight: Radius.zero,
                            bottomLeft: Radius.zero,
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'Ads in Progress',
                          style: GoogleFonts.poppins(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Success Bottom Sheet ──────────────────────────────────────────────────────
class _SuccessBottomSheet extends StatefulWidget {
  const _SuccessBottomSheet();

  @override
  State<_SuccessBottomSheet> createState() => _SuccessBottomSheetState();
}

class _SuccessBottomSheetState extends State<_SuccessBottomSheet>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Drag handle ───────────────────────────────────────────────
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFFD1D5DB),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 32),

          // ── Lottie animation ──────────────────────────────────────────
          Lottie.asset(
            'assets/ads/success.json',
            controller: _ctrl,
            width: double.infinity,
            height: 100,
            onLoaded: (composition) {
              _ctrl
                ..duration = composition.duration
                ..forward();
            },
          ),

          const SizedBox(height: 20),

          // ── "Submit Successfully" text ────────────────────────────────
          Text(
            'Submit Successfully',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: const Color(0xFF041B6B),
              letterSpacing: 0,
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }
}

// ── Loan Type Card ────────────────────────────────────────────────────────────
class _LoanTypeCard extends StatelessWidget {
  final String icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _LoanTypeCard({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    const gradient = LinearGradient(
      colors: [Color(0xFF2664EB), Color(0xFF004AC6)],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    );

    return GestureDetector(
      onTap: onTap,
      child: CustomPaint(
        painter: GradientBorderPainter(
          width: 1.0,
          radius: 14,
          gradient: gradient,
        ),
        child: Container(
          height: 110,
          decoration: BoxDecoration(
            gradient: gradient,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(icon, width: 48, height: 48),
              const SizedBox(height: 8),
              Text(
                label,
                style: GoogleFonts.poppins(
                  fontSize: 16.8,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Gradient Border Painter ───────────────────────────────────────────────────
class GradientBorderPainter extends CustomPainter {
  final double width;
  final double radius;
  final Gradient gradient;

  GradientBorderPainter({
    required this.width,
    required this.radius,
    required this.gradient,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final paint = Paint()
      ..strokeWidth = width
      ..shader = gradient.createShader(rect)
      ..style = PaintingStyle.stroke;
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    canvas.drawRRect(rrect, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// ── Form Field ────────────────────────────────────────────────────────────────
class _FormField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final TextInputType? keyboardType;

  const _FormField({
    required this.label,
    required this.controller,
    this.keyboardType,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 13,
            fontWeight: FontWeight.w400,
            height: 1.2,
            color: const Color(0xFF000000),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 46,
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            style: GoogleFonts.poppins(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              height: 1.0,
              color: const Color(0xFF525656),
            ),
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(
                  color: Color(0xFF004AC6),
                  width: 1,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(
                  color: Color(0xFF004AC6),
                  width: 1,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(
                  color: Color(0xFF004AC6),
                  width: 1.5,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
