import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MarketUser {
  final String name;
  final String role;
  final bool isPopular;
  final String requiredAmount;
  final String tenure;
  final String interestRate;
  final String income;
  final int creditScore;
  final String creditRatingText;
  final List<String> verifiedDocs;
  final String profileImage;
  final String category;

  const MarketUser({
    required this.name,
    required this.role,
    required this.isPopular,
    required this.requiredAmount,
    required this.tenure,
    required this.interestRate,
    required this.income,
    required this.creditScore,
    required this.creditRatingText,
    required this.verifiedDocs,
    required this.profileImage,
    required this.category,
  });
}

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({super.key});

  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen> {
  int _selectedFilter = 0; // 0=ALL, 1=BUSSINESS, 2=HOME
  int _selectedTab = 0; // 0=Lenders, 1=Borrowers
  final List<String> _filters = ['ALL', 'BUSSINESS', 'HOME'];

  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  final List<MarketUser> _lenders = [
    const MarketUser(
      name: 'Arjun Kumar',
      role: 'Individual Lender',
      isPopular: true,
      requiredAmount: '₹50,00,000',
      tenure: '36 Months',
      interestRate: '12% p.a.',
      income: '₹50,00,000',
      creditScore: 802,
      creditRatingText: '750+ EXCELLENT',
      verifiedDocs: [
        'Identity Verified',
        'Income Verified',
        'Credit Report Verified',
      ],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'BUSSINESS',
    ),
    const MarketUser(
      name: 'Priya Nair',
      role: 'Individual Lender',
      isPopular: false,
      requiredAmount: '₹30,00,000',
      tenure: '24 Months',
      interestRate: '11.5% p.a.',
      income: '₹35,00,000',
      creditScore: 785,
      creditRatingText: '750+ EXCELLENT',
      verifiedDocs: [
        'Identity Verified',
        'Income Verified',
        'Credit Report Verified',
      ],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'HOME',
    ),
    const MarketUser(
      name: 'Ravi Sharma',
      role: 'Individual Lender',
      isPopular: false,
      requiredAmount: '₹20,00,000',
      tenure: '18 Months',
      interestRate: '13% p.a.',
      income: '₹25,00,000',
      creditScore: 720,
      creditRatingText: '700+ GOOD',
      verifiedDocs: ['Identity Verified', 'Income Verified'],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'BUSSINESS',
    ),
    const MarketUser(
      name: 'Meena Devi',
      role: 'Individual Lender',
      isPopular: true,
      requiredAmount: '₹40,00,000',
      tenure: '48 Months',
      interestRate: '12.5% p.a.',
      income: '₹45,00,000',
      creditScore: 790,
      creditRatingText: '750+ EXCELLENT',
      verifiedDocs: [
        'Identity Verified',
        'Income Verified',
        'Credit Report Verified',
      ],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'HOME',
    ),
    const MarketUser(
      name: 'Suresh Kumar',
      role: 'Individual Lender',
      isPopular: false,
      requiredAmount: '₹15,00,000',
      tenure: '12 Months',
      interestRate: '14% p.a.',
      income: '₹18,00,000',
      creditScore: 680,
      creditRatingText: '650+ FAIR',
      verifiedDocs: ['Identity Verified'],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'BUSSINESS',
    ),
  ];

  final List<MarketUser> _borrowers = [
    const MarketUser(
      name: 'Arjun Kumar',
      role: 'Individual Borrower',
      isPopular: true,
      requiredAmount: '₹50,00,000',
      tenure: '36 Months',
      interestRate: '12% p.a.',
      income: '₹50,00,000',
      creditScore: 802,
      creditRatingText: '750+ EXCELLENT',
      verifiedDocs: [
        'Identity Verified',
        'Income Verified',
        'Credit Report Verified',
      ],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'BUSSINESS',
    ),
    const MarketUser(
      name: 'Priya Nair',
      role: 'Individual Borrower',
      isPopular: false,
      requiredAmount: '₹30,00,000',
      tenure: '24 Months',
      interestRate: '11.5% p.a.',
      income: '₹35,00,000',
      creditScore: 785,
      creditRatingText: '750+ EXCELLENT',
      verifiedDocs: [
        'Identity Verified',
        'Income Verified',
        'Credit Report Verified',
      ],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'HOME',
    ),
    const MarketUser(
      name: 'Ravi Sharma',
      role: 'Individual Borrower',
      isPopular: false,
      requiredAmount: '₹20,00,000',
      tenure: '18 Months',
      interestRate: '13% p.a.',
      income: '₹25,00,000',
      creditScore: 720,
      creditRatingText: '700+ GOOD',
      verifiedDocs: ['Identity Verified', 'Income Verified'],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'BUSSINESS',
    ),
    const MarketUser(
      name: 'Meena Devi',
      role: 'Individual Borrower',
      isPopular: true,
      requiredAmount: '₹40,00,000',
      tenure: '48 Months',
      interestRate: '12.5% p.a.',
      income: '₹45,00,000',
      creditScore: 790,
      creditRatingText: '750+ EXCELLENT',
      verifiedDocs: [
        'Identity Verified',
        'Income Verified',
        'Credit Report Verified',
      ],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'HOME',
    ),
    const MarketUser(
      name: 'Suresh Kumar',
      role: 'Individual Borrower',
      isPopular: false,
      requiredAmount: '₹15,00,000',
      tenure: '12 Months',
      interestRate: '14% p.a.',
      income: '₹18,00,000',
      creditScore: 680,
      creditRatingText: '650+ FAIR',
      verifiedDocs: ['Identity Verified'],
      profileImage: 'assets/home/mohan_profile.png',
      category: 'BUSSINESS',
    ),
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _showDetailsBottomSheet(MarketUser user) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final mediaQuery = MediaQuery.of(context);
        final screenHeight = mediaQuery.size.height;
        final statusBarHeight = mediaQuery.padding.top;
        // topOffset: 56.0 (AppBar) + 142.0 (Search & Chips container + clearance) + statusBarHeight
        final topOffset = statusBarHeight + 56.0 + 148.0;
        final bottomSheetHeight = screenHeight - topOffset;

        return _DetailsBottomSheet(user: user, height: bottomSheetHeight);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<MarketUser> rawList = _selectedTab == 0 ? _lenders : _borrowers;
    final List<MarketUser> filteredList = rawList.where((u) {
      if (_selectedFilter != 0) {
        final categoryStr = _filters[_selectedFilter];
        if (u.category != categoryStr) return false;
      }
      if (_searchQuery.isNotEmpty) {
        if (!u.name.toLowerCase().contains(_searchQuery)) return false;
      }
      return true;
    }).toList();

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // ── Blue AppBar ──────────────────────────────────────────────
          Container(
            color: const Color(0xFF004AC6),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(
                        Icons.arrow_back_rounded,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    Text(
                      'MarketPlace',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Scrollable Body ──────────────────────────────────────────
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: Column(
                children: [
                  // ── Grey Header Area (Search & Filters) ────────────────────────
                  Container(
                    color: const Color(0xFFF5F6FA),
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
                    child: Column(
                      children: [
                        // Search bar
                        Container(
                          height: 48,
                          decoration: BoxDecoration(
                            color: const Color(0xFFE9EDF5),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.search_rounded,
                                color: Color(0xFF727785),
                                size: 23,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: TextField(
                                  controller: _searchController,
                                  onChanged: (val) {
                                    setState(() {
                                      _searchQuery = val.trim().toLowerCase();
                                    });
                                  },
                                  decoration: InputDecoration(
                                    hintText: _selectedTab == 0
                                        ? 'Search lenders...'
                                        : 'Search borrowers...',
                                    hintStyle: GoogleFonts.inter(
                                      color: const Color(0xFF727785),
                                      fontSize: 13,
                                    ),
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.zero,
                                  ),
                                  style: GoogleFonts.inter(
                                    fontSize: 13,
                                    color: const Color(0xFF1E293B),
                                  ),
                                ),
                              ),
                              if (_searchQuery.isNotEmpty)
                                GestureDetector(
                                  onTap: () {
                                    _searchController.clear();
                                    setState(() {
                                      _searchQuery = "";
                                    });
                                  },
                                  child: const Icon(
                                    Icons.clear_rounded,
                                    color: Color(0xFF94A3B8),
                                    size: 18,
                                  ),
                                ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        // Filter chips
                        Row(
                          children: List.generate(
                            _filters.length,
                            (i) => Expanded(
                              child: Padding(
                                padding: EdgeInsets.only(
                                  right: i == _filters.length - 1 ? 0 : 8,
                                ),
                                child: GestureDetector(
                                  onTap: () =>
                                      setState(() => _selectedFilter = i),
                                  child: Container(
                                    height: 38,
                                    decoration: BoxDecoration(
                                      gradient: _selectedFilter == i
                                          ? const LinearGradient(
                                              colors: [
                                                Color(0xFF2230F6),
                                                Color(0xFF2563EB),
                                              ],
                                              begin: Alignment.centerLeft,
                                              end: Alignment.centerRight,
                                            )
                                          : null,
                                      color: _selectedFilter != i
                                          ? const Color(0xFF004AC6)
                                          : null,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      _filters[i].toUpperCase(),
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.inter(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ── Lenders / Borrowers Toggle ────────────────────────────────
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
                    child: Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () => setState(() => _selectedTab = 0),
                            child: Container(
                              height: 44,
                              decoration: BoxDecoration(
                                gradient: _selectedTab == 0
                                    ? const LinearGradient(
                                        colors: [
                                          Color(0xFF004AC6),
                                          Color(0xFF135AF7),
                                        ],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      )
                                    : null,
                                color: _selectedTab != 0 ? Colors.white : null,
                                borderRadius: BorderRadius.circular(24),
                                border: Border.all(
                                  color: const Color(0xFF004AC6),
                                  width: 1.5,
                                ),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                'Lenders',
                                style: GoogleFonts.inter(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: _selectedTab == 0
                                      ? Colors.white
                                      : const Color(0xFF004AC6),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: GestureDetector(
                            onTap: () => setState(() => _selectedTab = 1),
                            child: Container(
                              height: 44,
                              decoration: BoxDecoration(
                                gradient: _selectedTab == 1
                                    ? const LinearGradient(
                                        colors: [
                                          Color(0xFF004AC6),
                                          Color(0xFF135AF7),
                                        ],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      )
                                    : null,
                                color: _selectedTab != 1 ? Colors.white : null,
                                borderRadius: BorderRadius.circular(24),
                                border: Border.all(
                                  color: const Color(0xFF004AC6),
                                  width: 1.5,
                                ),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                'Borrowers',
                                style: GoogleFonts.inter(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: _selectedTab == 1
                                      ? Colors.white
                                      : const Color(0xFF004AC6),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const Divider(height: 1, color: Color(0xFFE2E8F0)),

                  // ── Market List ───────────────────────────────────────────────
                  Container(
                    color: Colors.white,
                    child: filteredList.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.symmetric(vertical: 40),
                            child: Center(
                              child: Text(
                                'No profiles found',
                                style: GoogleFonts.inter(
                                  color: const Color(0xFF94A3B8),
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          )
                        : ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
                            itemCount: filteredList.length,
                            itemBuilder: (context, index) => Padding(
                              padding: const EdgeInsets.only(bottom: 14),
                              child: _MarketCard(
                                user: filteredList[index],
                                onEyeTap: () => _showDetailsBottomSheet(
                                  filteredList[index],
                                ),
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MarketCard extends StatelessWidget {
  final MarketUser user;
  final VoidCallback onEyeTap;

  const _MarketCard({required this.user, required this.onEyeTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF006E2A), Color(0xFF14DA50)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0x0DFFFFFF), width: 1),
        boxShadow: const [
          BoxShadow(
            color: Color(0x1A000000),
            offset: Offset(0, 4),
            blurRadius: 6,
            spreadRadius: -4,
          ),
          BoxShadow(
            color: Color(0x1A000000),
            offset: Offset(0, 10),
            blurRadius: 15,
            spreadRadius: -3,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Row
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center,
                child: const Icon(
                  Icons.person_outline_rounded,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          user.name,
                          style: GoogleFonts.inter(
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            color: Colors.white,
                          ),
                        ),
                        if (user.isPopular)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFEAB308),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x0D000000),
                                  offset: Offset(0, 1),
                                  blurRadius: 2,
                                  spreadRadius: 0,
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.flash_on_rounded,
                                  color: Colors.white,
                                  size: 12,
                                ),
                                const SizedBox(width: 2),
                                Text(
                                  'Popular',
                                  style: GoogleFonts.inter(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      user.role,
                      style: GoogleFonts.inter(
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        color: Colors.white.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Divider Line
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Container(
              height: 1,
              color: Colors.white.withValues(alpha: 0.12),
            ),
          ),

          // Required Amount & Tenure Row (aligned in single horizontal lines)
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Required Amount',
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Colors.white.withValues(alpha: 0.6),
                    ),
                  ),
                  Text(
                    'Tenure',
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Colors.white.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    user.requiredAmount,
                    style: GoogleFonts.inter(
                      fontSize: 20,
                      fontWeight: FontWeight.w400,
                      color: Colors.white,
                    ),
                  ),
                  Transform.translate(
                    offset: const Offset(0, -1.5),
                    child: Text(
                      user.tenure,
                      style: GoogleFonts.inter(
                        fontSize: 15,
                        fontWeight: FontWeight.w400,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),

          // Bottom Action Buttons Row
          Padding(
            padding: const EdgeInsets.only(top: 14),
            child: Row(
              children: [
                SizedBox(
                  width: 225,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white.withValues(alpha: 0.1),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.zero,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Send Request',
                          style: GoogleFonts.inter(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 6),
                        const Icon(
                          Icons.arrow_forward_rounded,
                          color: Colors.white,
                          size: 14,
                        ),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('${user.name} bookmarked'),
                        backgroundColor: const Color(0xFF004AC6),
                      ),
                    );
                  },
                  behavior: HitTestBehavior.opaque,
                  child: const Icon(
                    Icons.bookmark_rounded,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: onEyeTap,
                  behavior: HitTestBehavior.opaque,
                  child: Image.asset(
                    'assets/market/eye.png',
                    width: 24,
                    height: 24,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(width: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailsBottomSheet extends StatelessWidget {
  final MarketUser user;
  final double height;

  const _DetailsBottomSheet({required this.user, required this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── Blue Gradient Header ─────────────────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 36),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF004AC6), Color(0xFF1D64FF)],
                stops: [0.1105, 0.5385],
                begin: Alignment(-0.8, -0.9), // ~96.71deg angle
                end: Alignment(0.8, 0.9),
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
                bottomLeft: Radius.circular(12),
                bottomRight: Radius.circular(12),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Top drag handle
                Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    // Avatar Image
                    Container(
                      width: 52,
                      height: 52,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white24,
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          user.profileImage,
                          width: 52,
                          height: 52,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return const Icon(
                              Icons.person,
                              color: Colors.white,
                              size: 28,
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user.name,
                            style: GoogleFonts.inter(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            user.role,
                            style: GoogleFonts.inter(
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                              color: Colors.white.withValues(alpha: 0.6),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Badge: EXCELLENT
                    Transform.translate(
                      offset: const Offset(0, -8),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.star_rounded,
                              color: Colors.white,
                              size: 12,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              user.creditRatingText,
                              style: GoogleFonts.poppins(
                                fontSize: 9,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ── Bottom Contents (Scrollable) ─────────────────────────────
          Expanded(
            child: SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // 2x2 Grid of Metrics
                    Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: _buildMetricCard(
                                "AMOUNT",
                                user.requiredAmount,
                                const Color(0xFF2664EB),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildMetricCard(
                                "INTEREST RATE",
                                user.interestRate,
                                const Color(0xFF2664EB),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: _buildMetricCard(
                                "INCOME",
                                user.income,
                                const Color(0xFF861E9D),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildMetricCard(
                                "CREDIT SCORE",
                                user.creditScore.toString(),
                                const Color(0xFF18B722),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    // Document Verification Card
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Document Verification',
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFF1E293B),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Column(
                            children: user.verifiedDocs.map((doc) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 10),
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons.check_circle_rounded,
                                      color: Color(0xFF004AC6),
                                      size: 18,
                                    ),
                                    const SizedBox(width: 10),
                                    Text(
                                      doc,
                                      style: GoogleFonts.poppins(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w500,
                                        color: const Color(0xFF475569),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricCard(String label, String value, Color valueColor) {
    return Container(
      height: 100,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            label,
            style: GoogleFonts.inter(
              fontSize: 10.5,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF64748B),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: GoogleFonts.inter(
              fontSize: 17.12,
              fontWeight: FontWeight.w600,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }
}
