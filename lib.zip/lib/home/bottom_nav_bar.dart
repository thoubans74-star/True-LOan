import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final VoidCallback onFabTap;

  const AppBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.onFabTap,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 84,
      child: Align(
        alignment: Alignment.bottomCenter,
        child: SizedBox(
          width: double.infinity,
          height: 60,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.topCenter,
            children: [
              // Shadow container (underneath)
              Positioned.fill(
                child: Container(
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(29.54),
                      topRight: Radius.circular(29.54),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x0D000000), // #0000000D
                        blurRadius: 36.92,
                        offset: Offset(0, -9.23),
                        spreadRadius: 0,
                      ),
                    ],
                  ),
                ),
              ),
              // Blurred background and content
              Positioned.fill(
                child: ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(29.54),
                    topRight: Radius.circular(29.54),
                  ),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 36.92, sigmaY: 36.92),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(29.54),
                          topRight: Radius.circular(29.54),
                        ),
                        border: Border.all(
                          color: const Color(0x1F000000), // 1.45px border
                          width: 1.45,
                        ),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _NavItem(
                            iconPath: 'assets/home/home.png',
                            label: 'HOME',
                            index: 0,
                            currentIndex: currentIndex,
                            onTap: onTap,
                          ),
                          _NavItem(
                            iconPath: 'assets/home/market.png',
                            label: 'MARKET',
                            index: 1,
                            currentIndex: currentIndex,
                            onTap: onTap,
                          ),
                          // Spacer for the center FAB
                          const SizedBox(width: 60),
                          _NavItem(
                            iconPath: 'assets/home/ads.png',
                            label: 'ADS',
                            index: 3,
                            currentIndex: currentIndex,
                            onTap: onTap,
                          ),
                          _NavItem(
                            iconPath: 'assets/home/profile.png',
                            label: 'PROFILE',
                            index: 4,
                            currentIndex: currentIndex,
                            onTap: onTap,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              // Center FAB using plus_home.png
              Positioned(
                top: -24, // float above
                child: GestureDetector(
                  onTap: onFabTap,
                  child: Image.asset(
                    'assets/home/plus_home.png',
                    width: 100,
                    height: 100,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final String iconPath;
  final String label;
  final int index;
  final int currentIndex;
  final ValueChanged<int> onTap;

  const _NavItem({
    required this.iconPath,
    required this.label,
    required this.index,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final bool isSelected = index == currentIndex;
    final Color activeColor = const Color(0xFF004AC6);
    final Color inactiveColor = const Color(0xFF94A3B8);

    return GestureDetector(
      onTap: () => onTap(index),
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 60,
        height: 60,
        child: Column(
          children: [
            // Top indicator bar
            Container(
              width: 44.30769348144531,
              height: 3.692307710647583,
              decoration: BoxDecoration(
                color: isSelected ? activeColor : Colors.transparent,
                borderRadius: BorderRadius.circular(9229.85),
              ),
            ),
            const Spacer(),
            // Image icon
            Image.asset(
              iconPath,
              width: 22,
              height: 22,
              color: isSelected ? activeColor : inactiveColor,
              colorBlendMode: BlendMode.srcIn,
            ),
            const SizedBox(height: 4),
            // Text label
            Text(
              label,
              style: GoogleFonts.poppins(
                fontSize: 9,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                color: isSelected ? activeColor : inactiveColor,
                letterSpacing: 0.3,
              ),
            ),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }
}
