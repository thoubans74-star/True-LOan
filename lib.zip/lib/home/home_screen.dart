import 'package:tm/fast_page_route.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'kyc_dialog.dart';
import 'request_screen.dart';
import '../profile/profile.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback? onProfileTap;
  final VoidCallback? onRequestTap;

  const HomeScreen({super.key, this.onProfileTap, this.onRequestTap});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Show KYC dialog when home screen opens
    WidgetsBinding.instance.addPostFrameCallback((_) {
      showKycDialog(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    final sw = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Blue Header Section ───────────────────────────────────
              _buildHeader(sw),

              const SizedBox(height: 16),

              // ── Stats Row ─────────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                ), // Starts/ends where search card starts/ends
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          if (widget.onRequestTap != null) {
                            widget.onRequestTap!();
                          } else {
                            Navigator.of(context).push(
                              FastPageRoute(
                                child: const RequestScreen(),
                              ),
                            );
                          }
                        },
                        child: _buildStatCard(
                          label: 'Request',
                          value: '48',
                          badge: '+12%',
                          badgeColor: const Color(0xFF22C55E),
                          imagePath: 'assets/home/request.png',
                          textBottom: 26, // Uplifted the '48' text
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildStatCard(
                        label: 'Total\nLoan',
                        value: '10',
                        imagePath: 'assets/home/total_loan.png',
                        textBottom: 14,
                        imageBottom: 2,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // ── Quick Actions ─────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Quick Actions',
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: const Color(0xFF171D17),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _buildQuickActionBox(
                            label: 'Match',
                            imagePath: 'assets/home/match.png',
                            gradientColors: const [
                              Color(0xFF894099),
                              Color(0xFFF09DFE),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              if (widget.onRequestTap != null) {
                                widget.onRequestTap!();
                              } else {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) => const RequestScreen(),
                                  ),
                                );
                              }
                            },
                            child: _buildQuickActionBox(
                              label: 'Request',
                              imagePath: 'assets/home/quick_request.png',
                              gradientColors: const [
                                Color(0xFFA13454),
                                Color(0xFFC14D6C),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _buildQuickActionBox(
                            label: 'Message',
                            imagePath: 'assets/home/message (2).png',
                            gradientColors: const [
                              Color(0xFF6200EE),
                              Color(0xFFBB86FC),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // ── Top Matches ───────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Top Matches',
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: const Color(0xFF171D17),
                      ),
                    ),
                    Text(
                      'View',
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: const Color(0xFF006B2A),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // ── Horizontal Match Cards ────────────────────────────────
              SizedBox(
                height: 180,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.only(left: 20, right: 4),
                  physics: const ClampingScrollPhysics(),
                  children: const [
                    _MatchCard(
                      name: 'Sowmiya',
                      role: 'Lender',
                      matchPercent: 97,
                      amount: '₹50,00,000',
                      roi: '10-14%',
                      tenure: '12-48M',
                    ),
                    SizedBox(width: 20),
                    _MatchCard(
                      name: 'Arjun Kumar',
                      role: 'Borrower',
                      matchPercent: 94,
                      amount: '₹30,00,000',
                      roi: '11-15%',
                      tenure: '24-60M',
                      gradientColors: [Color(0xFFE4EAE0), Color(0xFFDEE4DA)],
                      textColor: Colors.black,
                      badgeColor: Color(0x1A000000), // black with 10% opacity
                    ),
                    SizedBox(width: 20),
                    _MatchCard(
                      name: 'Priya Nair',
                      role: 'Lender',
                      matchPercent: 91,
                      amount: '₹20,00,000',
                      roi: '9-13%',
                      tenure: '12-36M',
                    ),
                    SizedBox(width: 16),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // ── Premium Banner ────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _buildPremiumBanner(),
              ),

              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    );
  }

  // ── Header ────────────────────────────────────────────────────────────────
  Widget _buildHeader(double sw) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF1A6AE8), Color(0xFF1644C8)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(32),
          bottomRight: Radius.circular(32),
        ),
      ),
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Top row: avatar + name + bell ─────────────────────────────
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Circular avatar with white border
              GestureDetector(
                onTap: () {
                  if (widget.onProfileTap != null) {
                    widget.onProfileTap!();
                  } else {
                    Navigator.of(context).push(
                      FastPageRoute(
                        child: const ProfileScreen(showBackButton: true),
                      ),
                    );
                  }
                },
                child: Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2.5),
                    image: const DecorationImage(
                      image: AssetImage('assets/home/mohan_profile.png'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              // Welcome text
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome back,',
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      color: const Color(
                        0xCCFFFFFF,
                      ), // #FFFFFFCC → alpha first in Flutter
                      fontWeight: FontWeight.w400,
                      height: 1.3,
                    ),
                  ),
                  Text(
                    'Sowmiya',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      height: 1.2,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              // Bell icon — blur + #FFFFFF33 border
              ClipOval(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                  child: Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFF6B82BF).withValues(alpha: 0.5),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0x33FFFFFF), // #FFFFFF33
                        width: 1,
                      ),
                    ),
                    child: const Icon(
                      Icons.notifications_outlined,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 18),

          // ── Search bar — white background ──────────────────────────────
          Container(
            height: 40,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Icon(Icons.search, color: const Color(0xFF525656), size: 24),
                const SizedBox(width: 10),
                Expanded(child: const SizedBox()),
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Icon(
                    Icons.mic_none_rounded,
                    color: const Color(0xFF525656),
                    size: 24,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── Credit Score + Maximum Eligibility card ────────────────────
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(16),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            child: Row(
              children: [
                // Left — Credit Score
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Credit Score',
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          color: const Color(0xCCFFFFFF),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '740',
                        style: GoogleFonts.poppins(
                          fontSize: 20,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          height: 1.7,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '+15 points this month',
                        style: GoogleFonts.poppins(
                          fontSize: 10,
                          color: const Color(0xCCFFFFFF),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),

                // Right — Maximum Eligibility
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Maximum Eligibility',
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          color: const Color(0xCCFFFFFF),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '₹15,00,000',
                        style: GoogleFonts.poppins(
                          fontSize: 20,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          height: 1.7,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '+15 points this month',
                        style: GoogleFonts.poppins(
                          fontSize: 10,
                          color: const Color(0xCCFFFFFF),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Stat Card ─────────────────────────────────────────────────────────────
  Widget _buildStatCard({
    required String label,
    required String value,
    String? badge,
    Color? badgeColor,
    required String imagePath,
    double textBottom = 22,
    double imageBottom = 16,
  }) {
    const double imgWidth = 56;
    const double imgHeight = 56;

    return Container(
      height: 124, // Increased height to prevent vertical pixel overflow
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE0E3E5), width: 0.92),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000), // #0000000D
            offset: Offset(0, 3.67),
            blurRadius: 11.01,
          ),
        ],
      ),
      child: Stack(
        children: [
          // Left side: Column containing Label and Value
          Positioned(
            left: 16,
            top: 12,
            bottom:
                textBottom, // Lifted slightly to pull value text up straight to image
            right:
                48, // Reduced from 64 to 48 to prevent 3-pixel RenderFlex overflow error
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  label,
                  style: GoogleFonts.poppins(
                    fontSize: 14.67,
                    fontWeight: FontWeight.w400,
                    fontStyle: FontStyle.normal,
                    color: const Color(0xFF64748B),
                    height: 22.01 / 14.67,
                    letterSpacing: 0,
                  ),
                ),
                Text(
                  value,
                  style: GoogleFonts.hankenGrotesk(
                    fontSize: 18.34,
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                    color: const Color(0xFF003178),
                    height: 25.68 / 18.34,
                    letterSpacing: 0,
                  ),
                ),
              ],
            ),
          ),

          // Right side Badge
          if (badge != null)
            Positioned(
              right: 16,
              top: 12,
              child: Container(
                width: 40, // Reduced badge card width to 40
                padding: const EdgeInsets.symmetric(vertical: 2),
                decoration: BoxDecoration(
                  color: (badgeColor ?? const Color(0xFF22C55E)).withValues(
                    alpha: 0.12,
                  ),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Text(
                    badge,
                    style: GoogleFonts.poppins(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: badgeColor ?? const Color(0xFF22C55E),
                    ),
                  ),
                ),
              ),
            ),

          // Right side Image
          Positioned(
            right: 16,
            bottom: imageBottom, // Lifted slightly from 12 to pull image up
            child: Image.asset(
              imagePath,
              width: imgWidth,
              height: imgHeight,
              fit: BoxFit.contain,
            ),
          ),
        ],
      ),
    );
  }

  // ── Quick Action ──────────────────────────────────────────────────────────
  Widget _buildQuickActionBox({
    required String label,
    required String imagePath,
    required List<Color> gradientColors,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: double.infinity,
          height: 82, // Restored the old visual height
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight, // Approx 135deg
              colors: gradientColors,
            ),
            borderRadius: BorderRadius.circular(17.51),
            boxShadow: const [
              BoxShadow(
                color: Color(0x1A000000), // #0000001A
                offset: Offset(0, 3.5),
                blurRadius: 5.25,
                spreadRadius: -3.5,
              ),
              BoxShadow(
                color: Color(0x1A000000), // #0000001A
                offset: Offset(0, 8.75),
                blurRadius: 13.13,
                spreadRadius: -2.63,
              ),
            ],
          ),
          child: Center(
            child: Image.asset(
              imagePath,
              width:
                  32, // Adjust size as needed since there is no circle container now
              height: 32,
              fit: BoxFit.contain,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 14.01,
            fontWeight: FontWeight.w400,
            fontStyle: FontStyle.normal,
            color: const Color(0xFF3F4A3E),
            height: 21.01 / 14.01,
            letterSpacing: 0,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  // ── Premium Banner ────────────────────────────────────────────────────────
  Widget _buildPremiumBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF005BDE), Color(0xFF003178)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.auto_awesome, color: Colors.white, size: 22),
          const SizedBox(height: 10),
          Text(
            'Unlock specialized rates\nbased on your industry\ntrends.',
            style: GoogleFonts.hankenGrotesk(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.white,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(6.77),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Upgrade to Premium',
                    style: GoogleFonts.poppins(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      foreground: Paint()
                        ..shader =
                            const LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Color(0xFF005BDE), Color(0xFF003178)],
                            ).createShader(
                              const Rect.fromLTWH(0.0, 0.0, 200.0, 70.0),
                            ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ShaderMask(
                    shaderCallback: (Rect bounds) {
                      return const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFF005BDE), Color(0xFF003178)],
                      ).createShader(bounds);
                    },
                    blendMode: BlendMode.srcIn,
                    child: const Icon(
                      Icons.diamond_outlined,
                      color: Colors.white, // Color is masked by ShaderMask
                      size: 24,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Match Card ───────────────────────────────────────────────────────────────
class _MatchCard extends StatelessWidget {
  final String name;
  final String role;
  final int matchPercent;
  final String amount;
  final String roi;
  final String tenure;
  final List<Color>? gradientColors;
  final Color? textColor;
  final Color? badgeColor;

  const _MatchCard({
    required this.name,
    required this.role,
    required this.matchPercent,
    required this.amount,
    required this.roi,
    required this.tenure,
    this.gradientColors,
    this.textColor,
    this.badgeColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 310,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors:
              gradientColors ?? const [Color(0xFF15863A), Color(0xFF006B2A)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight, // 135deg
        ),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Name row
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xFFE2E8F0),
                ),
                child: const Icon(
                  Icons.person,
                  color: Color(0xFF64748B),
                  size: 28,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: textColor ?? const Color(0xFFF7FFF2),
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      role,
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        color: textColor != null
                            ? textColor!.withValues(alpha: 0.7)
                            : Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: badgeColor ?? Colors.white.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Text(
                  '$matchPercent% Match',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: textColor ?? const Color(0xFFF7FFF2),
                  ),
                ),
              ),
            ],
          ),

          const Spacer(),

          // Amount
          Text(
            amount,
            style: GoogleFonts.inter(
              fontSize: 24,
              fontWeight: FontWeight.w400,
              color: textColor ?? const Color(0xFFF7FFF2),
              height: 1.0,
            ),
          ),

          const SizedBox(height: 12),

          // ROI + Tenure
          Row(
            children: [
              _infoChip('ROI: $roi'),
              const SizedBox(width: 24),
              _infoChip('Tenure: $tenure'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoChip(String text) {
    return Text(
      text,
      style: GoogleFonts.inter(
        fontSize: 14,
        color: textColor != null
            ? textColor!.withValues(alpha: 0.8)
            : const Color(0x80FFFFFF),
        fontWeight: FontWeight.w400,
      ),
    );
  }
}
