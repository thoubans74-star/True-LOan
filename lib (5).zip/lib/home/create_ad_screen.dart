import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tm/api_services/kyc_pending_verify_api_service.dart';
import 'package:tm/profile/kyc_verification.dart';
import 'package:tm/profile/kyc_pending_success_screens.dart';
import 'package:tm/home/loan_forms_screens.dart';
import 'package:tm/home/main_navigation.dart';

class CreateAdScreen extends StatefulWidget {
  final int initialSelectedType;
  const CreateAdScreen({super.key, this.initialSelectedType = -1});

  @override
  State<CreateAdScreen> createState() => _CreateAdScreenState();
}

class _CreateAdScreenState extends State<CreateAdScreen> {
  String _selectedRole = 'Select Role';
  bool _checkingKyc = false;

  @override
  void initState() {
    super.initState();
    if (widget.initialSelectedType == 0) {
      _selectedRole = 'Borrower';
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _handleBorrowerFlow();
      });
    } else if (widget.initialSelectedType == 1) {
      _selectedRole = 'Lender';
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _handleLenderFlow();
      });
    }
  }

  void _showRoleSelectionSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
      ),
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
          ),
          padding: EdgeInsets.fromLTRB(24.w, 16.h, 24.w, 32.h),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Drag handle
              Center(
                child: Container(
                  width: 40.w,
                  height: 4.h,
                  decoration: BoxDecoration(
                    color: const Color(0xFFD1D5DB),
                    borderRadius: BorderRadius.circular(2.r),
                  ),
                ),
              ),
              SizedBox(height: 24.h),
              Text(
                'Select Application Role',
                style: GoogleFonts.poppins(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w500,
                  color: const Color(0xFF0F172A),
                ),
              ),
              SizedBox(height: 20.h),

              // Option 1: Borrower
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _selectedRole = 'Borrower');
                  _handleBorrowerFlow();
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(color: const Color(0xFFEEF2F6), width: 1.5),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 42.w,
                        height: 42.w,
                        decoration: const BoxDecoration(
                          color: Color(0xFFE8F2FF),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.arrow_downward_rounded,
                          color: const Color(0xFF1A6AE8),
                          size: 20.w,
                        ),
                      ),
                      SizedBox(width: 16.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Borrower',
                              style: GoogleFonts.poppins(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFF0F172A),
                              ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              'Need a loan for personal, business, home or vehicle requirements',
                              style: GoogleFonts.poppins(
                                fontSize: 11.sp,
                                color: const Color(0xFF64748B),
                                height: 1.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 8.w),
                      Icon(
                        Icons.chevron_right_rounded,
                        color: const Color(0xFF94A3B8),
                        size: 24.w,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 14.h),

              // Option 2: Lender
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _selectedRole = 'Lender');
                  _handleLenderFlow();
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(color: const Color(0xFFEEF2F6), width: 1.5),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 42.w,
                        height: 42.w,
                        decoration: const BoxDecoration(
                          color: Color(0xFFE8FDF0),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.arrow_upward_rounded,
                          color: const Color(0xFF10B981),
                          size: 20.w,
                        ),
                      ),
                      SizedBox(width: 16.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Lender',
                              style: GoogleFonts.poppins(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFF0F172A),
                              ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              'Fund borrowers and gain interest returns securely',
                              style: GoogleFonts.poppins(
                                fontSize: 11.sp,
                                color: const Color(0xFF64748B),
                                height: 1.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 8.w),
                      Icon(
                        Icons.chevron_right_rounded,
                        color: const Color(0xFF94A3B8),
                        size: 24.w,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _handleBorrowerFlow() async {
    setState(() {
      _checkingKyc = true;
    });

    final res = await KycPendingVerifyApiService.checkKycStatus();
    
    setState(() {
      _checkingKyc = false;
    });

    if (mounted) {
      if (res != null) {
        final dynamic dataVal = res['data'];
        final dynamic kycStatusVal = res['kyc_status'] ?? (dataVal is Map ? dataVal['kyc_status'] : null);
        final int kycStatus = int.tryParse(kycStatusVal?.toString() ?? '') ?? 0;
        final String status = (res['status'] ?? (dataVal is Map ? dataVal['status'] : '') ?? '').toString().toLowerCase();
        final String message = (res['message'] ?? (dataVal is Map ? dataVal['message'] : '') ?? '').toString().toLowerCase();

        // If KYC is verified/approved/success/kycStatus==1, proceed directly to form
        if (kycStatus == 1 ||
            status == 'verified' ||
            status == 'approved' ||
            status == 'success' ||
            status == '1' ||
            message.contains('verified') ||
            message.contains('approved') ||
            message.contains('success')) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const NeedALoanFormScreen()),
          );
        } else if (dataVal is Map && dataVal.isNotEmpty) {
          // If already submitted and pending review, redirect to loading screen
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const KycPendingScreen(isFromProfile: false)),
          );
        } else {
          // Otherwise, open KYC verification bottom sheet
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
            ),
            builder: (context) => const KycVerificationBottomSheet(),
          );
        }
      } else {
        // Fallback to KYC verification bottom sheet if API check fails
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
          ),
          builder: (context) => const KycVerificationBottomSheet(),
        );
      }
    }
  }

  void _handleLenderFlow() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const GiveALoanFormScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // ── App Header (Blue AppBar) ───────────────────────────────────
          Container(
            color: const Color(0xFF004AC6),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.maybePop(context),
                      icon: Icon(
                        Icons.arrow_back_rounded,
                        color: Colors.white,
                        size: 24.w,
                      ),
                    ),
                    Text(
                      'Loan Services',
                      style: GoogleFonts.poppins(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () {
                        Navigator.of(context).pushAndRemoveUntil(
                          PageRouteBuilder(
                            pageBuilder: (context, animation, secondaryAnimation) =>
                                const MainNavigationScreen(),
                            transitionsBuilder:
                                (context, animation, secondaryAnimation, child) {
                              const begin = Offset(-1.0, 0.0);
                              const end = Offset.zero;
                              const curve = Curves.easeInOut;
                              var tween = Tween(begin: begin, end: end)
                                  .chain(CurveTween(curve: curve));
                              return SlideTransition(
                                position: animation.drive(tween),
                                child: child,
                              );
                            },
                            transitionDuration: const Duration(milliseconds: 400),
                          ),
                          (route) => false,
                        );
                      },
                      icon: Icon(
                        Icons.home_rounded,
                        color: Colors.white,
                        size: 24.w,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Content Area ───────────────────────────────────────────────
          Expanded(
            child: Stack(
              children: [
                SingleChildScrollView(
                  physics: const ClampingScrollPhysics(),
                  padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 24.h),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Select Your Application Role',
                        style: GoogleFonts.poppins(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                          color: const Color(0xFF0F172A),
                        ),
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        'Choose whether you want to apply for a loan as a borrower or fund requirements as a lender.',
                        style: GoogleFonts.poppins(
                          fontSize: 11.sp,
                          color: const Color(0xFF64748B),
                          height: 1.4,
                        ),
                      ),
                      SizedBox(height: 32.h),

                      // Dropdown Selector Trigger
                      GestureDetector(
                        onTap: _showRoleSelectionSheet,
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12.r),
                            border: Border.all(color: const Color(0xFF004AC6), width: 1.2),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.person_outline_rounded,
                                color: const Color(0xFF004AC6),
                                size: 22.w,
                              ),
                              SizedBox(width: 12.w),
                              Text(
                                _selectedRole,
                                style: GoogleFonts.poppins(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w500,
                                  color: _selectedRole == 'Select Role'
                                      ? const Color(0xFF94A3B8)
                                      : const Color(0xFF0F172A),
                                ),
                              ),
                              const Spacer(),
                              Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color: const Color(0xFF64748B),
                                size: 22.w,
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 48.h),

                      // Smart Loan Matching Card
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(24.w),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF8FAFC),
                          borderRadius: BorderRadius.circular(16.r),
                        ),
                        child: Column(
                          children: [
                            Container(
                              width: 56.w,
                              height: 56.w,
                              decoration: const BoxDecoration(
                                color: Color(0xFFE8F2FF),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.psychology_alt_rounded,
                                color: const Color(0xFF1A6AE8),
                                size: 28.w,
                              ),
                            ),
                            SizedBox(height: 16.h),
                            Text(
                              'Smart Loan Matching',
                              style: GoogleFonts.poppins(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xFF0F172A),
                              ),
                            ),
                            SizedBox(height: 8.h),
                            Text(
                              'Our platform instantly matches verified borrowers with verified lenders to ensure quick, transparent, and seamless loan agreements.',
                              style: GoogleFonts.poppins(
                                fontSize: 10.sp,
                                color: const Color(0xFF64748B),
                                height: 1.5,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // KYC Status API Check Loading Overlay
                if (_checkingKyc)
                  Container(
                    color: Colors.black.withValues(alpha: 0.3),
                    alignment: Alignment.center,
                    child: Container(
                      padding: EdgeInsets.all(24.w),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF004AC6)),
                          ),
                          SizedBox(height: 16.h),
                          Text(
                            'Checking KYC status...',
                            style: GoogleFonts.poppins(
                              fontSize: 13.sp,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xFF0F172A),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
