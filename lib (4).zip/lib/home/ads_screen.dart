import 'dart:convert';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'marketplace_screen.dart';

class AdsScreen extends StatefulWidget {
  const AdsScreen({super.key});

  @override
  State<AdsScreen> createState() => _AdsScreenState();
}

class _AdsScreenState extends State<AdsScreen> {
  List<MarketUser> _bookmarkedUsers = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadBookmarks();
  }

  Future<void> _loadBookmarks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<String> bookmarkedJsonList = prefs.getStringList('bookmarked_users') ?? [];
      final List<MarketUser> users = [];
      for (var jsonStr in bookmarkedJsonList) {
        try {
          final decoded = jsonDecode(jsonStr);
          users.add(MarketUser.fromJson(decoded));
        } catch (_) {}
      }
      if (mounted) {
        setState(() {
          _bookmarkedUsers = users;
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint('Error loading bookmarks: $e');
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showDetailsBottomSheet(MarketUser user) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final mediaQuery = MediaQuery.of(context);
        final screenHeight = mediaQuery.size.height;
        final statusBarHeight = mediaQuery.padding.top;
        final topOffset = statusBarHeight + 56.0 + 148.0;
        final bottomSheetHeight = screenHeight - topOffset;

        return DetailsBottomSheet(user: user, height: bottomSheetHeight);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: Column(
        children: [
          // ── Blue AppBar ──────────────────────────────────────────────────
          Container(
            color: const Color(0xFF004AC6),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
                child: Row(
                  children: [
                    if (Navigator.of(context).canPop())
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: Icon(
                          Icons.arrow_back_rounded,
                          color: Colors.white,
                          size: 24.w,
                        ),
                      )
                    else
                      SizedBox(width: 16.w),
                    Text(
                      'Book Marks',
                      style: GoogleFonts.poppins(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Bookmarks List ──────────────────────────────────────────────
          Expanded(
            child: _isLoading
                ? const Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFF004AC6),
                    ),
                  )
                : _bookmarkedUsers.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.bookmark_border_rounded,
                              color: const Color(0xFF94A3B8),
                              size: 48.w,
                            ),
                            SizedBox(height: 12.h),
                            Text(
                              'No Bookmarks Saved',
                              style: GoogleFonts.poppins(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: EdgeInsets.fromLTRB(20.w, 16.h, 20.w, 100.h),
                        physics: const ClampingScrollPhysics(),
                        itemCount: _bookmarkedUsers.length,
                        itemBuilder: (context, index) {
                          final user = _bookmarkedUsers[index];
                          return Padding(
                            padding: EdgeInsets.only(bottom: 14.h),
                            child: MarketCard(
                              user: user,
                              onViewDetailsTap: () => _showDetailsBottomSheet(user),
                              onBookmarkToggle: _loadBookmarks,
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
