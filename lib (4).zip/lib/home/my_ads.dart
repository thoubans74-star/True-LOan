import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:shared_preferences/shared_preferences.dart';
import '../api_services/marketplace_api_service.dart';

class MyAdsScreen extends StatefulWidget {
  const MyAdsScreen({super.key});

  @override
  State<MyAdsScreen> createState() => _MyAdsScreenState();
}

class _MyAdsScreenState extends State<MyAdsScreen> {
  List<Map<String, dynamic>> _myAds = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadMyAds();
  }

  Future<void> _loadMyAds() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String currentUserId = prefs.getString('user_id') ?? '';
      final String cachedName = prefs.getString('name') ?? 'Mohan';

      final lenders = await MarketplaceApiService.fetchLenders();
      final borrowers = await MarketplaceApiService.fetchBorrowers();

      final List<Map<String, dynamic>> combined = [];

      if (lenders != null) {
        final filteredLenders = lenders
            .where((l) => l['ledger_name']?.toString() == currentUserId)
            .map((l) {
              final amt = l['loan_amt'];
              final tenure = l['loan_tenure'];
              return {
                'name': cachedName,
                'role': 'Individual Lender',
                'requiredAmount': amt != null ? '₹$amt' : '₹0',
                'tenure': tenure != null ? '$tenure Months' : '12 Months',
              };
            })
            .toList();
        combined.addAll(filteredLenders);
      }

      if (borrowers != null) {
        final filteredBorrowers = borrowers
            .where((b) => b['ledger_name']?.toString() == currentUserId)
            .map((b) {
              final amt = b['loan_amt'];
              final tenure = b['loan_tenure'];
              return {
                'name': cachedName,
                'role': 'Individual Borrower',
                'requiredAmount': amt != null ? '₹$amt' : '₹0',
                'tenure': tenure != null ? '$tenure Months' : '12 Months',
              };
            })
            .toList();
        combined.addAll(filteredBorrowers);
      }

      if (mounted) {
        setState(() {
          _myAds = combined;
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint('Error loading user ads: $e');
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: Column(
        children: [
          // ── Blue AppBar ──────────────────────────────────────────────────
          Container(
            color: const Color(0xFF004AC6),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: Icon(
                        Icons.arrow_back_rounded,
                        color: Colors.white,
                        size: 24.w,
                      ),
                    ),
                    Text(
                      'My Ads',
                      style: GoogleFonts.poppins(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Ads List ──────────────────────────────────────────────────
          Expanded(
            child: _isLoading
                ? const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Color(0xFF004AC6),
                      ),
                    ),
                  )
                : _myAds.isEmpty
                ? Center(
                    child: Text(
                      'No ads submitted yet.',
                      style: GoogleFonts.poppins(
                        color: const Color(0xFF64748B),
                        fontSize: 14.sp,
                      ),
                    ),
                  )
                : ListView.builder(
                    padding: EdgeInsets.fromLTRB(20.w, 16.h, 20.w, 100.h),
                    physics: const ClampingScrollPhysics(),
                    itemCount: _myAds.length,
                    itemBuilder: (context, index) {
                      final ad = _myAds[index];
                      return Padding(
                        padding: EdgeInsets.only(bottom: 14.h),
                        child: _MyAdListCard(
                          name: ad['name'] ?? 'Mohan',
                          role: ad['role'] ?? '',
                          requiredAmount: ad['requiredAmount'] ?? '',
                          tenure: ad['tenure'] ?? '',
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _MyAdListCard extends StatelessWidget {
  final String name;
  final String role;
  final String requiredAmount;
  final String tenure;

  const _MyAdListCard({
    required this.name,
    required this.role,
    required this.requiredAmount,
    required this.tenure,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: const Color(0xFFE2E8F0), width: 1),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000), // #0000000D
            offset: Offset(0, 4),
            blurRadius: 10,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header Row: Avatar + Name/Role
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12.r),
                child: Image.asset(
                  'assets/home/mohan_profile.png',
                  width: 46.w,
                  height: 46.w,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      width: 46.w,
                      height: 46.w,
                      color: const Color(0xFFF1F5F9),
                      child: Icon(
                        Icons.person,
                        color: const Color(0xFF64748B),
                        size: 24.w,
                      ),
                    );
                  },
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.poppins(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF0F172A),
                      ),
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      role,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.poppins(
                        fontSize: 12.sp,
                        color: const Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Divider Line
          Padding(
            padding: EdgeInsets.symmetric(vertical: 12.h),
            child: Container(height: 1, color: const Color(0xFFEEF2F6)),
          ),

          // Required Amount & Tenure Row (Exactly like Marketplace Card)
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Required Amount',
                    style: GoogleFonts.poppins(
                      fontSize: 12.sp,
                      color: const Color(0xFF64748B),
                    ),
                  ),
                  Text(
                    'Tenure',
                    style: GoogleFonts.poppins(
                      fontSize: 12.sp,
                      color: const Color(0xFF64748B),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 4.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    requiredAmount,
                    style: GoogleFonts.inter(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF003178),
                    ),
                  ),
                  Text(
                    tenure,
                    style: GoogleFonts.poppins(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF1E293B),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
