import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class NeedALoanApiService {
  static const String baseUrl = 'https://trueloan.ai.in/ai/api/m_api/';

  /// Submits the Need a Loan form data to the server (type 1111)
  static Future<Map<String, dynamic>?> submitNeedALoan({
    required String loanType,
    required String loanAmt,
    required String interest,
    required String loanTenure,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String deviceId = prefs.getString('device_id') ?? '234';
      final String ln = prefs.getString('ln') ?? '445';
      final String lt = prefs.getString('lt') ?? '345';
      final String userId = prefs.getString('user_id') ?? '38';

      final response = await http.post(
        Uri.parse(baseUrl),
        body: {
          'type': '1111',
          'cid': '21472147',
          'device_id': deviceId,
          'ln': ln,
          'lt': lt,
          'form': 'sm_main_form_10101',
          'ledger_name': userId,
          'loan_type': loanType,
          'loan_amt': loanAmt,
          'interest': interest,
          'loan_tenure': loanTenure,
        },
      );

      debugPrint('[Need A Loan Submit (1111)] Request device_id: $deviceId, ln: $ln, lt: $lt, ledger_name: $userId');
      debugPrint('[Need A Loan Submit (1111)] Status: ${response.statusCode}, Body: ${response.body}');

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      }
    } catch (e) {
      debugPrint('Error in submitNeedALoan: $e');
    }
    return null;
  }
}
