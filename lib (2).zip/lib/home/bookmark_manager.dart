import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'marketplace_screen.dart';

class BookmarkManager {
  static const String _key = 'bookmarked_ads';
  static final ValueNotifier<List<MarketUser>> bookmarksNotifier =
      ValueNotifier<List<MarketUser>>([]);

  /// Loads bookmarks from SharedPreferences
  static Future<void> loadBookmarks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<String> list = prefs.getStringList(_key) ?? [];
      final List<MarketUser> loaded = list.map((item) {
        return MarketUser.fromJson(jsonDecode(item));
      }).toList();
      bookmarksNotifier.value = loaded;
    } catch (e) {
      debugPrint('Error loading bookmarks: $e');
    }
  }

  /// Toggles the bookmark state of a MarketUser
  static Future<void> toggleBookmark(MarketUser user) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<MarketUser> current = List.from(bookmarksNotifier.value);
      final int index =
          current.indexWhere((u) => u.phone == user.phone && u.name == user.name);

      if (index >= 0) {
        current.removeAt(index);
      } else {
        current.add(user);
      }

      bookmarksNotifier.value = current;

      final List<String> listToSave =
          current.map((u) => jsonEncode(u.toJson())).toList();
      await prefs.setStringList(_key, listToSave);
    } catch (e) {
      debugPrint('Error toggling bookmark: $e');
    }
  }

  /// Checks if a MarketUser is bookmarked
  static bool isBookmarked(MarketUser user) {
    return bookmarksNotifier.value.any((u) => u.phone == user.phone && u.name == user.name);
  }
}
