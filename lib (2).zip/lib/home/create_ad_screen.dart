import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:tm/profile/verification_sheets.dart';

class CreateAdScreen extends StatefulWidget {
  final int initialSelectedType;
  const CreateAdScreen({super.key, this.initialSelectedType = -1});

  @override
  State<CreateAdScreen> createState() => _CreateAdScreenState();
}

class _CreateAdScreenState extends State<CreateAdScreen> {
  int _selectedType = -1; // 0 = Need a Loan, 1 = Give a Loan
  bool _submitted = false;

  @override
  void initState() {
    super.initState();
    _selectedType = widget.initialSelectedType;
  }

  final _loanAmountController = TextEditingController(text: '₹ 500000');
  final _interestRateController = TextEditingController(text: '12');
  final _tenureController = TextEditingController(text: '24');
  final _purposeController = TextEditingController(
    text: 'Business, Education, Personal',
  );

  @override
  void dispose() {
    _loanAmountController.dispose();
    _interestRateController.dispose();
    _tenureController.dispose();
    _purposeController.dispose();
    super.dispose();
  }

  Future<void> _onSubmitTap() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black.withValues(alpha: 0.45),
      builder: (_) => const _SuccessBottomSheet(),
    );
    // After the sheet is dismissed, mark submitted
    if (mounted) setState(() => _submitted = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // ── Blue AppBar (Same header like marketplace) ──────────────────
          Container(
            color: const Color(0xFF004AC6),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: Icon(
                        Icons.arrow_back_rounded,
                        color: Colors.white,
                        size: 24.w,
                      ),
                    ),
                    Text(
                      'Create Advertisement',
                      style: GoogleFonts.poppins(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Content ───────────────────────────────────────────────────
          Expanded(
            child: SingleChildScrollView(
              physics:  ClampingScrollPhysics(),
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Submitted success banner ───────────────────────────
                  if (_submitted) ...[
                    Container(
                      width: double.infinity,
                      margin: EdgeInsets.only(bottom: 16.h),
                      decoration: BoxDecoration(
                        color:  Color(0xFFEFFFF4),
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                      child: IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // ── Left accent gradient bar ───────────────────
                            Container(
                              width: 5.w,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color(0xFF1B8A3D),
                                    Color(0xFF072410),
                                  ],
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                ),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(12.r),
                                  bottomLeft: Radius.circular(12.r),
                                ),
                              ),
                            ),
                            // ── Text content ──────────────────────────────
                            Expanded(
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 14.w,
                                  vertical: 14.h,
                                ),
                                child: ShaderMask(
                                  shaderCallback: (bounds) =>
                                      LinearGradient(
                                        colors: [
                                          Color(0xFF1B8A3D),
                                          Color(0xFF072410),
                                        ],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      ).createShader(bounds),
                                  blendMode: BlendMode.srcIn,
                                  child: RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: 'Ad submitted!\n',
                                          style: GoogleFonts.poppins(
                                            fontSize: 14.sp,
                                            fontWeight: FontWeight.w600,
                                            height: 1.75,
                                            letterSpacing: 0,
                                            color: Colors.white,
                                          ),
                                        ),
                                        TextSpan(
                                          text:
                                              'Under review — usually approved within 24h.',
                                          style: GoogleFonts.poppins(
                                            fontSize: 12.sp,
                                            fontWeight: FontWeight.w500,
                                            height: 1.75,
                                            letterSpacing: 0,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],

                  // ── Loan Type Selector ─────────────────────────────────
                  Row(
                    children: [
                      Expanded(
                        child: _LoanTypeCard(
                          icon: 'assets/ads/need_a_loan.png',
                          label: 'Need a Loan',
                          isSelected: _selectedType == 0,
                          onTap: () => setState(() => _selectedType = 0),
                        ),
                      ),
                      SizedBox(width: 12.w),
                      Expanded(
                        child: _LoanTypeCard(
                          icon: 'assets/ads/give_a_loan.png',
                          label: 'Give a Loan',
                          isSelected: _selectedType == 1,
                          onTap: () {
                            showSectorSelectionBottomSheet(
                              context,
                              onSuccess: () {
                                setState(() => _selectedType = 1);
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 20.h),

                  // ── Form Fields (All same width) ───────────────────────
                  _FormField(
                    label: 'Loan Amount (₹)',
                    controller: _loanAmountController,
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 14.h),
                  _FormField(
                    label: 'Interest Rate (% p.a.)',
                    controller: _interestRateController,
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 14.h),
                  _FormField(
                    label: 'Tenure (months)',
                    controller: _tenureController,
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 14.h),
                  _FormField(label: 'Purpose', controller: _purposeController),

                  SizedBox(height: 24.h),

                  // ── Submit Button ──────────────────────────────────────
                  SizedBox(
                    width: double.infinity,
                    height: 50.h,
                    child: ElevatedButton(
                      onPressed: _onSubmitTap,
                      style: ElevatedButton.styleFrom(
                        backgroundColor:  Color(0xFF004AC6),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        elevation: 0,
                      ),
                      child: Text(
                        'Submit For Review',
                        style: GoogleFonts.poppins(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),

                  if (_submitted) ...[
                    SizedBox(height: 20.h),

                    // ── Create Advertisement section ───────────────────────
                    Text(
                      'Create Advertisement',
                      style: GoogleFonts.poppins(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF000000),
                      ),
                    ),

                    SizedBox(height: 12.h),

                    // ── Ads in Progress button ─────────────────────────────
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        width: double.infinity,
                        height: 50.h,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFF1B8A3D), Color(0xFF1ADB56)],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20.r),
                            bottomRight: Radius.circular(20.r),
                            topRight: Radius.zero,
                            bottomLeft: Radius.zero,
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'Ads in Progress',
                          style: GoogleFonts.poppins(
                            fontSize: 13.sp,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],

                  SizedBox(height: 80.h),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Success Bottom Sheet ──────────────────────────────────────────────────────
class _SuccessBottomSheet extends StatefulWidget {
  const _SuccessBottomSheet();

  @override
  State<_SuccessBottomSheet> createState() => _SuccessBottomSheetState();
}

class _SuccessBottomSheetState extends State<_SuccessBottomSheet>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28.r)),
      ),
      padding: EdgeInsets.fromLTRB(24, 16, 24, 40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Drag handle ───────────────────────────────────────────────
          Container(
            width: 40.w,
            height: 4.h,
            decoration: BoxDecoration(
              color:  Color(0xFFD1D5DB),
              borderRadius: BorderRadius.circular(2.r),
            ),
          ),
          SizedBox(height: 32.h),

          // ── Lottie animation ──────────────────────────────────────────
          Lottie.asset(
            'assets/ads/success.json',
            controller: _ctrl,
            width: double.infinity,
            height: 100.h,
            onLoaded: (composition) {
              _ctrl
                ..duration = composition.duration
                ..forward();
            },
          ),

          SizedBox(height: 20.h),

          // ── "Submit Successfully" text ────────────────────────────────
          Text(
            'Submit Successfully',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
              color: const Color(0xFF041B6B),
              letterSpacing: 0,
            ),
          ),

          SizedBox(height: 32.h),
        ],
      ),
    );
  }
}

// ── Loan Type Card ────────────────────────────────────────────────────────────
class _LoanTypeCard extends StatelessWidget {
  final String icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _LoanTypeCard({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    const gradient = LinearGradient(
      colors: [Color(0xFF2664EB), Color(0xFF004AC6)],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    );

    return GestureDetector(
      onTap: onTap,
      child: CustomPaint(
        painter: GradientBorderPainter(
          width: 1.0,
          radius: 14,
          gradient: gradient,
        ),
        child: Container(
          height: 110.h,
          decoration: BoxDecoration(
            gradient: gradient,
            borderRadius: BorderRadius.circular(14.r),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(icon, width: 48.w, height: 48.h),
              SizedBox(height: 8.h),
              Text(
                label,
                style: GoogleFonts.poppins(
                  fontSize: 16.8.sp,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Gradient Border Painter ───────────────────────────────────────────────────
class GradientBorderPainter extends CustomPainter {
  final double width;
  final double radius;
  final Gradient gradient;

  GradientBorderPainter({
    required this.width,
    required this.radius,
    required this.gradient,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final paint = Paint()
      ..strokeWidth = width
      ..shader = gradient.createShader(rect)
      ..style = PaintingStyle.stroke;
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    canvas.drawRRect(rrect, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// ── Form Field ────────────────────────────────────────────────────────────────
class _FormField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final TextInputType? keyboardType;

  const _FormField({
    required this.label,
    required this.controller,
    this.keyboardType,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 13.sp,
            fontWeight: FontWeight.w400,
            height: 1.2,
            color:  Color(0xFF000000),
          ),
        ),
        SizedBox(height: 8.h),
        SizedBox(
          height: 46.h,
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            style: GoogleFonts.poppins(
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
              height: 1.0,
              color: const Color(0xFF525656),
            ),
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white,
              contentPadding: EdgeInsets.symmetric(horizontal: 14.w),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.r),
                borderSide: const BorderSide(
                  color: Color(0xFF004AC6),
                  width: 1,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.r),
                borderSide: const BorderSide(
                  color: Color(0xFF004AC6),
                  width: 1,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.r),
                borderSide: const BorderSide(
                  color: Color(0xFF004AC6),
                  width: 1.5,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
